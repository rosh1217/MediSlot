import { useState } from 'react';
import { Mail, Lock, LogIn, AlertCircle, Info } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';

export default function Login() {
  const { signIn } = useAuth();
  const { navigate } = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const { error } = await signIn(email, password);
    setLoading(false);
    if (error) {
      setError(error);
      return;
    }
    navigate('/');
  }

  function quickLogin(em: string) {
    setEmail(em);
    setPassword(em.includes('admin') ? 'adminpass123' : em.includes('patient') ? 'patientpass123' : 'doctorpass123');
  }

  return (
    <div className="mx-auto flex min-h-[80vh] max-w-md flex-col justify-center px-4 py-12">
      <div className="card p-8 shadow-lg">
        <div className="text-center">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-primary-50 text-primary-600">
            <LogIn className="h-6 w-6" />
          </div>
          <h1 className="mt-4 text-2xl font-bold text-slate-900">Welcome back</h1>
          <p className="mt-1 text-sm text-slate-500">Sign in to manage your appointments.</p>
        </div>

        {error && (
          <div className="mt-6 flex items-start gap-2 rounded-xl bg-red-50 p-3 text-sm text-red-700">
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div>
            <label className="label">Email</label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input type="email" required className="input pl-10" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
          </div>
          <div>
            <label className="label">Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input type="password" required className="input pl-10" placeholder="••••••••" value={password} onChange={(e) => setPassword(e.target.value)} />
            </div>
          </div>
          <button type="submit" disabled={loading} className="btn-primary w-full">
            {loading ? <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" /> : 'Sign in'}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-slate-500">
          Don't have an account?{' '}
          <a href="#/register" className="font-semibold text-primary-600 hover:text-primary-700">Register</a>
        </p>

        <div className="mt-6 rounded-xl bg-primary-50/60 p-4">
          <div className="flex items-center gap-2 text-xs font-semibold text-primary-700">
            <Info className="h-4 w-4" />
            Demo accounts (click to autofill)
          </div>
          <div className="mt-2 space-y-1.5 text-sm">
            <button onClick={() => quickLogin('patient@demo.com')} className="block w-full rounded-lg px-3 py-1.5 text-left text-slate-600 hover:bg-white">
              <span className="font-medium text-slate-700">Patient:</span> patient@demo.com · patientpass123
            </button>
            <button onClick={() => quickLogin('dr.sarah@mgmhospital.com')} className="block w-full rounded-lg px-3 py-1.5 text-left text-slate-600 hover:bg-white">
              <span className="font-medium text-slate-700">Doctor:</span> dr.sarah@mgmhospital.com · doctorpass123
            </button>
            <button onClick={() => quickLogin('admin@mgmhospital.com')} className="block w-full rounded-lg px-3 py-1.5 text-left text-slate-600 hover:bg-white">
              <span className="font-medium text-slate-700">Admin:</span> admin@mgmhospital.com · adminpass123
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
