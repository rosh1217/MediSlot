import { useEffect, useState } from 'react';
import { Search, Stethoscope, SlidersHorizontal, X, ArrowRight } from 'lucide-react';
import { Link } from '@/context/RouterContext';
import { supabase, type Department, type DoctorProfile } from '@/lib/supabase';
import { formatCurrency } from '@/lib/utils';
import { getDepartmentIcon } from '@/lib/icons';

export default function DoctorDirectory() {
  const [doctors, setDoctors] = useState<DoctorProfile[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [deptFilter, setDeptFilter] = useState('');

  useEffect(() => {
    const hash = window.location.hash;
    const queryIdx = hash.indexOf('?');
    if (queryIdx >= 0) {
      const params = new URLSearchParams(hash.slice(queryIdx + 1));
      setSearch(params.get('q') ?? '');
      setDeptFilter(params.get('dept') ?? '');
    }
  }, []);

  useEffect(() => {
    supabase.from('departments').select('*').eq('active', true).order('name').then(({ data }) => setDepartments(data ?? []));
  }, []);

  useEffect(() => {
    setLoading(true);
    let q = supabase
      .from('doctor_profiles')
      .select('*, department:departments(*)')
      .eq('active', true);
    if (deptFilter) q = q.eq('department_id', deptFilter);
    if (search) q = q.or(`full_name.ilike.%${search}%,specialization.ilike.%${search}%`);
    q.order('full_name').then(({ data }) => {
      setDoctors(data ?? []);
      setLoading(false);
    });
  }, [search, deptFilter]);

  function clearFilters() {
    setSearch('');
    setDeptFilter('');
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-slate-900">Find a Doctor</h1>
        <p className="mt-2 text-lg text-slate-500">Browse our specialists and book an appointment.</p>
      </div>

      {/* Search & filter bar */}
      <div className="mt-8 card p-4 sm:p-5">
        <div className="flex flex-col gap-3 sm:flex-row">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              className="input pl-10"
              placeholder="Search by name or specialization..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="relative sm:w-56">
            <SlidersHorizontal className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <select className="input pl-10" value={deptFilter} onChange={(e) => setDeptFilter(e.target.value)}>
              <option value="">All departments</option>
              {departments.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
          </div>
          {(search || deptFilter) && (
            <button onClick={clearFilters} className="btn-ghost">
              <X className="h-4 w-4" />
              Clear
            </button>
          )}
        </div>
      </div>

      {/* Results */}
      <div className="mt-8">
        {loading ? (
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="card h-64 animate-pulse bg-slate-100" />
            ))}
          </div>
        ) : doctors.length === 0 ? (
          <div className="card p-12 text-center">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-slate-100 text-slate-400">
              <Stethoscope className="h-8 w-8" />
            </div>
            <h3 className="mt-4 text-lg font-semibold text-slate-900">No doctors found</h3>
            <p className="mt-1 text-sm text-slate-500">Try adjusting your search or clearing filters.</p>
            <button onClick={clearFilters} className="btn-outline mt-5">Clear filters</button>
          </div>
        ) : (
          <>
            <p className="mb-4 text-sm text-slate-500">{doctors.length} doctor{doctors.length !== 1 ? 's' : ''} available</p>
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {doctors.map((doc) => (
                <div key={doc.id} className="card group overflow-hidden hover:-translate-y-1 hover:shadow-md">
                  <div className="aspect-[4/3] overflow-hidden bg-slate-100">
                    {doc.photo_url ? (
                      <img src={doc.photo_url} alt={doc.full_name} className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" />
                    ) : (
                      <div className="flex h-full items-center justify-center text-slate-300"><Stethoscope className="h-12 w-12" /></div>
                    )}
                  </div>
                  <div className="p-5">
                    <div className="flex items-center gap-2">
                      {doc.department && (
                        <span className="badge bg-primary-50 text-primary-700">
                          {(() => { const Icon = getDepartmentIcon(doc.department.icon); return <Icon className="h-3 w-3" />; })()}
                          {doc.department.name}
                        </span>
                      )}
                    </div>
                    <h3 className="mt-3 text-lg font-bold text-slate-900">{doc.full_name}</h3>
                    <p className="text-sm text-primary-600">{doc.specialization}</p>
                    <p className="mt-1 text-sm text-slate-500">{doc.qualification}</p>
                    <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-4">
                      <div>
                        <span className="text-xs text-slate-400">Consultation</span>
                        <div className="font-bold text-slate-900">{formatCurrency(doc.consultation_fee)}</div>
                      </div>
                      <Link to={`/doctors/${doc.id}`} className="btn-primary !px-4 !py-2 text-xs">
                        Book now
                        <ArrowRight className="h-3 w-3" />
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
