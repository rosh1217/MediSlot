import { useEffect, useState } from 'react';
import { ArrowRight } from 'lucide-react';
import { Link } from '@/context/RouterContext';
import { supabase, type Department } from '@/lib/supabase';
import { getDepartmentIcon } from '@/lib/icons';

export default function Departments() {
  const [departments, setDepartments] = useState<Department[]>([]);
  const [counts, setCounts] = useState<Record<string, number>>({});

  useEffect(() => {
    supabase.from('departments').select('*').eq('active', true).order('name').then(({ data }) => {
      setDepartments(data ?? []);
      (data ?? []).forEach((d) => {
        supabase.from('doctor_profiles').select('id', { count: 'exact', head: true }).eq('department_id', d.id).eq('active', true).then(({ count }) => {
          setCounts((prev) => ({ ...prev, [d.id]: count ?? 0 }));
        });
      });
    });
  }, []);

  return (
    <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-slate-900">Departments</h1>
        <p className="mt-2 text-lg text-slate-500">Explore our specialist departments and the doctors within them.</p>
      </div>
      <div className="mt-10 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {departments.map((dept) => {
          const Icon = getDepartmentIcon(dept.icon);
          return (
            <div key={dept.id} className="card group p-6 hover:-translate-y-1 hover:shadow-md">
              <div className="flex items-start gap-4">
                <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-primary-50 text-primary-600 transition-colors group-hover:bg-primary-600 group-hover:text-white">
                  <Icon className="h-7 w-7" />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-slate-900">{dept.name}</h3>
                  <p className="mt-1 text-sm text-slate-500">{dept.description}</p>
                  <div className="mt-4 flex items-center justify-between">
                    <span className="text-sm text-slate-400">{counts[dept.id] ?? 0} doctor{(counts[dept.id] ?? 0) !== 1 ? 's' : ''}</span>
                    <Link to={`/doctors?dept=${dept.id}`} className="inline-flex items-center gap-1 text-sm font-semibold text-primary-600 hover:text-primary-700">
                      View doctors
                      <ArrowRight className="h-3 w-3" />
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
