import { useEffect, useState } from 'react';
import { ArrowLeft, Stethoscope, GraduationCap, Briefcase, IndianRupee, Calendar, Clock, CheckCircle2, AlertCircle, Lock } from 'lucide-react';
import { Link, useRouter } from '@/context/RouterContext';
import { useAuth } from '@/context/AuthContext';
import { supabase, type DoctorProfile, type Slot } from '@/lib/supabase';
import { formatCurrency, formatTime, next7Days, generateBookingReference, isPastSlot } from '@/lib/utils';

export default function DoctorProfilePage({ doctorId }: { doctorId: string }) {
  const { profile } = useAuth();
  const { navigate } = useRouter();
  const [doctor, setDoctor] = useState<DoctorProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState(next7Days()[0].value);
  const [slots, setSlots] = useState<Slot[]>([]);
  const [slotsLoading, setSlotsLoading] = useState(true);
  const [selectedSlot, setSelectedSlot] = useState<Slot | null>(null);
  const [notes, setNotes] = useState('');
  const [booking, setBooking] = useState(false);
  const [bookingResult, setBookingResult] = useState<{ success: boolean; reference?: string; error?: string } | null>(null);

  useEffect(() => {
    supabase
      .from('doctor_profiles')
      .select('*, department:departments(*)')
      .eq('id', doctorId)
      .maybeSingle()
      .then(({ data }) => {
        setDoctor(data as DoctorProfile | null);
        setLoading(false);
      });
  }, [doctorId]);

  useEffect(() => {
    setSlotsLoading(true);
    setSelectedSlot(null);
    supabase
      .from('appointment_slots')
      .select('*')
      .eq('doctor_id', doctorId)
      .eq('appointment_date', selectedDate)
      .order('start_time')
      .then(({ data }) => {
        setSlots(data ?? []);
        setSlotsLoading(false);
      });
  }, [doctorId, selectedDate]);

  async function handleBook() {
    if (!selectedSlot || !doctor || !profile) return;
    setBooking(true);
    setBookingResult(null);

    // Re-check slot availability
    const { data: freshSlot } = await supabase
      .from('appointment_slots')
      .select('status')
      .eq('id', selectedSlot.id)
      .maybeSingle();

    if (!freshSlot || freshSlot.status !== 'available') {
      setBooking(false);
      setBookingResult({ success: false, error: 'This slot was just taken. Please select another.' });
      return;
    }

    const reference = generateBookingReference();

    // Create appointment + mark slot booked
    const { error: apptError } = await supabase.from('appointments').insert({
      booking_reference: reference,
      patient_id: profile.id,
      doctor_id: doctor.id,
      slot_id: selectedSlot.id,
      department_id: doctor.department_id,
      appointment_date: selectedSlot.appointment_date,
      start_time: selectedSlot.start_time,
      end_time: selectedSlot.end_time,
      consultation_fee: doctor.consultation_fee,
      status: 'booked',
      patient_notes: notes || null,
    });

    if (apptError) {
      setBooking(false);
      setBookingResult({ success: false, error: apptError.code === '23505' ? 'This slot was just booked by someone else.' : apptError.message });
      return;
    }

    await supabase.from('appointment_slots').update({ status: 'booked' }).eq('id', selectedSlot.id);

    setBooking(false);
    setBookingResult({ success: true, reference });
    setSelectedSlot(null);
    setNotes('');
  }

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-3 border-primary-200 border-t-primary-600" />
      </div>
    );
  }

  if (!doctor) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-16 text-center">
        <h1 className="text-2xl font-bold text-slate-900">Doctor not found</h1>
        <Link to="/doctors" className="btn-primary mt-6">Back to directory</Link>
      </div>
    );
  }

  if (bookingResult?.success) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16">
        <div className="card p-8 text-center shadow-lg animate-scale-in">
          <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-accent-50 text-accent-600">
            <CheckCircle2 className="h-10 w-10" />
          </div>
          <h1 className="mt-6 text-2xl font-bold text-slate-900">Appointment booked!</h1>
          <p className="mt-2 text-slate-500">Your appointment with {doctor.full_name} is confirmed.</p>
          <div className="mt-6 rounded-xl bg-slate-50 p-5 text-left">
            <div className="text-xs font-medium uppercase tracking-wide text-slate-400">Booking reference</div>
            <div className="mt-1 text-xl font-bold text-primary-600">{bookingResult.reference}</div>
            <div className="mt-4 space-y-2 text-sm text-slate-600">
              <div className="flex justify-between"><span>Doctor</span><span className="font-medium">{doctor.full_name}</span></div>
              <div className="flex justify-between"><span>Department</span><span className="font-medium">{doctor.department?.name}</span></div>
              <div className="flex justify-between"><span>Date</span><span className="font-medium">{selectedDate}</span></div>
              <div className="flex justify-between"><span>Time</span><span className="font-medium">{formatTime(slots.find(s => s.id === selectedSlot?.id)?.start_time ?? '')}</span></div>
              <div className="flex justify-between"><span>Fee</span><span className="font-medium">{formatCurrency(doctor.consultation_fee)}</span></div>
            </div>
          </div>
          <p className="mt-4 text-xs text-slate-400">Please arrive 15 minutes before your appointment. You can cancel up to 2 hours before the scheduled time.</p>
          <div className="mt-6 flex gap-3 justify-center">
            <Link to="/patient/dashboard" className="btn-primary">View my appointments</Link>
            <Link to="/doctors" className="btn-outline">Book another</Link>
          </div>
        </div>
      </div>
    );
  }

  const days = next7Days();

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
      <Link to="/doctors" className="btn-ghost mb-6 -ml-3">
        <ArrowLeft className="h-4 w-4" />
        Back to doctors
      </Link>

      <div className="grid gap-8 lg:grid-cols-3">
        {/* Profile card */}
        <div className="lg:col-span-1">
          <div className="card overflow-hidden">
            <div className="aspect-square overflow-hidden bg-slate-100">
              {doctor.photo_url ? (
                <img src={doctor.photo_url} alt={doctor.full_name} className="h-full w-full object-cover" />
              ) : (
                <div className="flex h-full items-center justify-center text-slate-300"><Stethoscope className="h-16 w-16" /></div>
              )}
            </div>
            <div className="p-5">
              <h1 className="text-xl font-bold text-slate-900">{doctor.full_name}</h1>
              <p className="text-sm text-primary-600">{doctor.specialization}</p>
              <p className="mt-1 text-sm text-slate-500">{doctor.department?.name}</p>
              <div className="mt-4 space-y-2 border-t border-slate-100 pt-4 text-sm">
                <InfoRow icon={<GraduationCap className="h-4 w-4" />}>{doctor.qualification}</InfoRow>
                <InfoRow icon={<Briefcase className="h-4 w-4" />}>{doctor.experience_years} years experience</InfoRow>
                <InfoRow icon={<IndianRupee className="h-4 w-4" />}>{formatCurrency(doctor.consultation_fee)} consultation</InfoRow>
              </div>
            </div>
          </div>
        </div>

        {/* Booking section */}
        <div className="lg:col-span-2">
          <div className="card p-6">
            <h2 className="text-lg font-bold text-slate-900">About</h2>
            <p className="mt-2 text-sm text-slate-600">{doctor.biography}</p>

            {!profile ? (
              <div className="mt-6 rounded-xl bg-warm-50 p-5 text-center">
                <Lock className="mx-auto h-8 w-8 text-warm-500" />
                <h3 className="mt-3 font-semibold text-slate-900">Sign in to book</h3>
                <p className="mt-1 text-sm text-slate-500">You need a patient account to book an appointment.</p>
                <div className="mt-4 flex justify-center gap-3">
                  <Link to="/login" className="btn-primary">Sign in</Link>
                  <Link to="/register" className="btn-outline">Register</Link>
                </div>
              </div>
            ) : profile.role !== 'patient' ? (
              <div className="mt-6 rounded-xl bg-slate-50 p-5 text-center text-sm text-slate-500">
                You are signed in as a {profile.role}. Only patient accounts can book appointments.
              </div>
            ) : (
              <div className="mt-6">
                <h3 className="font-semibold text-slate-900">Select a date</h3>
                <div className="mt-3 flex gap-2 overflow-x-auto pb-2">
                  {days.map((d) => (
                    <button
                      key={d.value}
                      onClick={() => setSelectedDate(d.value)}
                      className={`flex min-w-[72px] flex-col items-center rounded-xl border px-3 py-2.5 transition-all ${
                        selectedDate === d.value
                          ? 'border-primary-600 bg-primary-600 text-white'
                          : 'border-slate-200 bg-white text-slate-600 hover:border-primary-300'
                      }`}
                    >
                      <span className="text-xs font-medium">{d.label}</span>
                      <span className="text-sm font-bold">{d.sub}</span>
                    </button>
                  ))}
                </div>

                <h3 className="mt-6 font-semibold text-slate-900">Available slots</h3>
                {slotsLoading ? (
                  <div className="mt-3 grid grid-cols-3 gap-2 sm:grid-cols-4">
                    {[...Array(8)].map((_, i) => <div key={i} className="h-10 animate-pulse rounded-lg bg-slate-100" />)}
                  </div>
                ) : slots.filter((s) => s.status === 'available' && !isPastSlot(s.appointment_date, s.start_time)).length === 0 ? (
                  <div className="mt-3 rounded-xl bg-slate-50 p-6 text-center text-sm text-slate-500">
                    <Clock className="mx-auto h-8 w-8 text-slate-300" />
                    <p className="mt-2">No available slots for this date. Try another day.</p>
                  </div>
                ) : (
                  <div className="mt-3 grid grid-cols-3 gap-2 sm:grid-cols-4">
                    {slots.map((slot) => {
                      const available = slot.status === 'available' && !isPastSlot(slot.appointment_date, slot.start_time);
                      return (
                        <button
                          key={slot.id}
                          disabled={!available}
                          onClick={() => setSelectedSlot(slot)}
                          className={`rounded-lg border px-2 py-2 text-sm font-medium transition-all ${
                            !available
                              ? 'border-slate-100 bg-slate-50 text-slate-300 cursor-not-allowed'
                              : selectedSlot?.id === slot.id
                              ? 'border-accent-500 bg-accent-500 text-white'
                              : 'border-slate-200 bg-white text-slate-700 hover:border-accent-400 hover:text-accent-600'
                          }`}
                        >
                          {formatTime(slot.start_time)}
                        </button>
                      );
                    })}
                  </div>
                )}

                {selectedSlot && (
                  <div className="mt-6 rounded-xl border border-primary-200 bg-primary-50/50 p-5 animate-fade-up">
                    <div className="flex items-center gap-2 text-sm font-semibold text-primary-700">
                      <Calendar className="h-4 w-4" />
                      {selectedDate} at {formatTime(selectedSlot.start_time)}
                    </div>
                    <div className="mt-3">
                      <label className="label">Notes for the doctor (optional)</label>
                      <textarea rows={2} className="input resize-none" placeholder="Brief reason for visit..." value={notes} onChange={(e) => setNotes(e.target.value)} />
                    </div>
                    <div className="mt-4 flex items-center justify-between">
                      <div className="text-sm text-slate-600">
                        Consultation fee: <span className="font-bold text-slate-900">{formatCurrency(doctor.consultation_fee)}</span>
                      </div>
                      <button onClick={handleBook} disabled={booking} className="btn-accent">
                        {booking ? <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" /> : 'Confirm booking'}
                      </button>
                    </div>
                  </div>
                )}

                {bookingResult?.error && (
                  <div className="mt-4 flex items-start gap-2 rounded-xl bg-red-50 p-3 text-sm text-red-700 animate-fade-in">
                    <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                    {bookingResult.error}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoRow({ icon, children }: { icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-2 text-slate-600">
      <span className="text-slate-400">{icon}</span>
      {children}
    </div>
  );
}
