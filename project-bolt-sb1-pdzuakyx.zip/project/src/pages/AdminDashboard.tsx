import { useEffect, useState } from 'react';
import { Users, Stethoscope, CalendarDays, Activity, Shield, Plus, Trash2, X, AlertCircle } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { supabase, type Department, type DoctorProfile, type Appointment, type Profile } from '@/lib/supabase';
import { formatDate, formatTime, formatCurrency } from '@/lib/utils';

type Tab = 'overview' | 'doctors' | 'departments' | 'patients' | 'appointments';

export default function AdminDashboard() {
  const [tab, setTab] = useState<Tab>('overview');
  const [doctors, setDoctors] = useState<DoctorProfile[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [patients, setPatients] = useState<Profile[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);

  async function loadAll() {
    const [d, deps, p, a] = await Promise.all([
      supabase.from('doctor_profiles').select('*, department:departments(*)').order('full_name'),
      supabase.from('departments').select('*').order('name'),
      supabase.from('profiles').select('id, full_name, phone, role, active').eq('role', 'patient').order('full_name'),
      supabase.from('appointments').select('*, doctor:doctor_profiles(*), patient:profiles!appointments_patient_id_fkey(full_name), department:departments(*)').order('created_at', { ascending: false }).limit(50),
    ]);
    setDoctors(d.data ?? []);
    setDepartments(deps.data ?? []);
    setPatients(p.data ?? []);
    setAppointments(a.data ?? []);
  }

  useEffect(() => { loadAll(); }, []);

  const today = new Date().toISOString().slice(0, 10);
  const todayAppts = appointments.filter((a) => a.appointment_date === today);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary-50 text-primary-600">
          <Shield className="h-5 w-5" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Admin Panel</h1>
          <p className="text-sm text-slate-500">MediSlot — system administration</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="mt-8 flex gap-1 overflow-x-auto border-b border-slate-200">
        <TabBtn active={tab === 'overview'} onClick={() => setTab('overview')}>Overview</TabBtn>
        <TabBtn active={tab === 'doctors'} onClick={() => setTab('doctors')}>Doctors</TabBtn>
        <TabBtn active={tab === 'departments'} onClick={() => setTab('departments')}>Departments</TabBtn>
        <TabBtn active={tab === 'patients'} onClick={() => setTab('patients')}>Patients</TabBtn>
        <TabBtn active={tab === 'appointments'} onClick={() => setTab('appointments')}>Appointments</TabBtn>
      </div>

      {tab === 'overview' && (
        <div className="mt-6">
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            <StatCard icon={<Users className="h-6 w-6" />} value={patients.length} label="Patients" color="primary" />
            <StatCard icon={<Stethoscope className="h-6 w-6" />} value={doctors.filter(d => d.active).length} label="Active doctors" color="accent" />
            <StatCard icon={<CalendarDays className="h-6 w-6" />} value={todayAppts.length} label="Today's appointments" color="warm" />
            <StatCard icon={<Activity className="h-6 w-6" />} value={appointments.length} label="Total appointments" color="primary" />
          </div>

          <div className="mt-8 card p-6">
            <h2 className="text-lg font-bold text-slate-900">Recent bookings</h2>
            <div className="mt-4 space-y-2">
              {appointments.slice(0, 8).map((a) => (
                <div key={a.id} className="flex items-center justify-between rounded-lg border border-slate-100 p-3 text-sm">
                  <div>
                    <span className="font-medium text-slate-800">{a.patient?.full_name}</span>
                    <span className="text-slate-400"> → </span>
                    <span className="text-slate-600">{a.doctor?.full_name}</span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-slate-400">
                    <span>{formatDate(a.appointment_date)} · {formatTime(a.start_time)}</span>
                    <span className={`badge ${a.status === 'booked' ? 'bg-accent-50 text-accent-700' : a.status === 'cancelled' ? 'bg-red-50 text-red-600' : 'bg-primary-50 text-primary-700'}`}>{a.status}</span>
                  </div>
                </div>
              ))}
              {appointments.length === 0 && <p className="text-sm text-slate-400">No appointments yet.</p>}
            </div>
          </div>
        </div>
      )}

      {tab === 'doctors' && <ManageDoctors doctors={doctors} departments={departments} onReload={loadAll} />}
      {tab === 'departments' && <ManageDepartments departments={departments} onReload={loadAll} />}
      {tab === 'patients' && (
        <div className="mt-6 card p-6">
          <h2 className="text-lg font-bold text-slate-900">Registered patients</h2>
          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-left text-xs uppercase text-slate-400">
                  <th className="py-2 pr-4">Name</th>
                  <th className="py-2 pr-4">Phone</th>
                  <th className="py-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {patients.map((p) => (
                  <tr key={p.id} className="border-b border-slate-50">
                    <td className="py-3 pr-4 font-medium text-slate-800">{p.full_name}</td>
                    <td className="py-3 pr-4 text-slate-600">{p.phone}</td>
                    <td className="py-3"><span className={`badge ${p.active ? 'bg-accent-50 text-accent-700' : 'bg-slate-100 text-slate-500'}`}>{p.active ? 'active' : 'inactive'}</span></td>
                  </tr>
                ))}
                {patients.length === 0 && <tr><td colSpan={3} className="py-6 text-center text-slate-400">No patients registered.</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      )}
      {tab === 'appointments' && (
        <div className="mt-6 card p-6">
          <h2 className="text-lg font-bold text-slate-900">All appointments</h2>
          <div className="mt-4 space-y-2">
            {appointments.map((a) => (
              <div key={a.id} className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-slate-100 p-3 text-sm">
                <div>
                  <span className="font-medium text-slate-800">{a.patient?.full_name}</span>
                  <span className="text-slate-400"> → </span>
                  <span className="text-slate-600">{a.doctor?.full_name}</span>
                  <span className="ml-2 text-xs text-slate-400">{a.department?.name}</span>
                </div>
                <div className="flex items-center gap-3 text-xs text-slate-400">
                  <span>{formatDate(a.appointment_date)} · {formatTime(a.start_time)}</span>
                  <span>{formatCurrency(a.consultation_fee)}</span>
                  <span className={`badge ${a.status === 'booked' ? 'bg-accent-50 text-accent-700' : a.status === 'cancelled' ? 'bg-red-50 text-red-600' : 'bg-primary-50 text-primary-700'}`}>{a.status}</span>
                </div>
              </div>
            ))}
            {appointments.length === 0 && <p className="text-sm text-slate-400">No appointments yet.</p>}
          </div>
        </div>
      )}
    </div>
  );
}

function ManageDoctors({ doctors, departments, onReload }: { doctors: DoctorProfile[]; departments: Department[]; onReload: () => void }) {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ full_name: '', qualification: '', specialization: '', department_id: '', consultation_fee: '500', experience_years: '5', biography: '' });
  const [error, setError] = useState<string | null>(null);

  async function addDoctor() {
    setError(null);
    if (!form.full_name || !form.department_id) {
      setError('Name and department are required.');
      return;
    }
    const { error } = await supabase.from('doctor_profiles').insert({
      full_name: form.full_name,
      qualification: form.qualification,
      specialization: form.specialization,
      department_id: form.department_id,
      consultation_fee: parseFloat(form.consultation_fee),
      experience_years: parseInt(form.experience_years),
      biography: form.biography,
      active: true,
    });
    if (error) { setError(error.message); return; }
    setForm({ full_name: '', qualification: '', specialization: '', department_id: '', consultation_fee: '500', experience_years: '5', biography: '' });
    setShowForm(false);
    onReload();
  }

  async function toggleActive(doc: DoctorProfile) {
    await supabase.from('doctor_profiles').update({ active: !doc.active }).eq('id', doc.id);
    onReload();
  }

  return (
    <div className="mt-6">
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-bold text-slate-900">Manage doctors</h2>
        <button onClick={() => setShowForm(v => !v)} className="btn-primary">
          <Plus className="h-4 w-4" />
          Add doctor
        </button>
      </div>

      {showForm && (
        <div className="mt-4 card p-6 animate-fade-up">
          <div className="grid gap-4 sm:grid-cols-2">
            <div><label className="label">Full name</label><input className="input" value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} /></div>
            <div><label className="label">Specialization</label><input className="input" value={form.specialization} onChange={(e) => setForm({ ...form, specialization: e.target.value })} /></div>
            <div><label className="label">Qualification</label><input className="input" value={form.qualification} onChange={(e) => setForm({ ...form, qualification: e.target.value })} /></div>
            <div><label className="label">Department</label>
              <select className="input" value={form.department_id} onChange={(e) => setForm({ ...form, department_id: e.target.value })}>
                <option value="">Select department</option>
                {departments.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
              </select>
            </div>
            <div><label className="label">Consultation fee (₹)</label><input type="number" className="input" value={form.consultation_fee} onChange={(e) => setForm({ ...form, consultation_fee: e.target.value })} /></div>
            <div><label className="label">Experience (years)</label><input type="number" className="input" value={form.experience_years} onChange={(e) => setForm({ ...form, experience_years: e.target.value })} /></div>
            <div className="sm:col-span-2"><label className="label">Biography</label><textarea rows={2} className="input resize-none" value={form.biography} onChange={(e) => setForm({ ...form, biography: e.target.value })} /></div>
          </div>
          {error && <div className="mt-3 flex items-center gap-2 text-sm text-red-600"><AlertCircle className="h-4 w-4" />{error}</div>}
          <div className="mt-4 flex gap-3">
            <button onClick={addDoctor} className="btn-primary">Save doctor</button>
            <button onClick={() => setShowForm(false)} className="btn-outline">Cancel</button>
          </div>
        </div>
      )}

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        {doctors.map((doc) => (
          <div key={doc.id} className="card p-4">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-semibold text-slate-900">{doc.full_name}</h3>
                <p className="text-sm text-primary-600">{doc.specialization}</p>
                <p className="text-xs text-slate-400">{doc.department?.name} · {formatCurrency(doc.consultation_fee)}</p>
              </div>
              <span className={`badge ${doc.active ? 'bg-accent-50 text-accent-700' : 'bg-slate-100 text-slate-500'}`}>{doc.active ? 'active' : 'inactive'}</span>
            </div>
            <button onClick={() => toggleActive(doc)} className="btn-ghost mt-3 text-sm">
              {doc.active ? 'Deactivate' : 'Activate'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

function ManageDepartments({ departments, onReload }: { departments: Department[]; onReload: () => void }) {
  const [name, setName] = useState('');
  const [desc, setDesc] = useState('');
  const [error, setError] = useState<string | null>(null);

  async function addDept() {
    setError(null);
    if (!name) { setError('Name is required.'); return; }
    const { error } = await supabase.from('departments').insert({ name, description: desc, active: true });
    if (error) { setError(error.message); return; }
    setName(''); setDesc('');
    onReload();
  }

  async function toggleActive(d: Department) {
    await supabase.from('departments').update({ active: !d.active }).eq('id', d.id);
    onReload();
  }

  return (
    <div className="mt-6">
      <h2 className="text-lg font-bold text-slate-900">Manage departments</h2>
      <div className="mt-4 card p-6">
        <div className="grid gap-4 sm:grid-cols-3">
          <div><label className="label">Name</label><input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Oncology" /></div>
          <div className="sm:col-span-2"><label className="label">Description</label><input className="input" value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="Short description" /></div>
        </div>
        {error && <div className="mt-3 flex items-center gap-2 text-sm text-red-600"><AlertCircle className="h-4 w-4" />{error}</div>}
        <button onClick={addDept} className="btn-primary mt-4"><Plus className="h-4 w-4" />Add department</button>
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {departments.map((d) => (
          <div key={d.id} className="card p-4">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-semibold text-slate-900">{d.name}</h3>
                <p className="text-sm text-slate-500">{d.description}</p>
              </div>
              <span className={`badge ${d.active ? 'bg-accent-50 text-accent-700' : 'bg-slate-100 text-slate-500'}`}>{d.active ? 'active' : 'inactive'}</span>
            </div>
            <button onClick={() => toggleActive(d)} className="btn-ghost mt-3 text-sm">{d.active ? 'Deactivate' : 'Activate'}</button>
          </div>
        ))}
      </div>
    </div>
  );
}

function StatCard({ icon, value, label, color }: { icon: React.ReactNode; value: number; label: string; color: 'primary' | 'accent' | 'warm' }) {
  const c = { primary: 'bg-primary-50 text-primary-600', accent: 'bg-accent-50 text-accent-600', warm: 'bg-warm-50 text-warm-600' };
  return (
    <div className="card flex items-center gap-3 p-4">
      <div className={`flex h-11 w-11 items-center justify-center rounded-xl ${c[color]}`}>{icon}</div>
      <div>
        <div className="text-2xl font-extrabold text-slate-900">{value}</div>
        <div className="text-xs text-slate-500">{label}</div>
      </div>
    </div>
  );
}

function TabBtn({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button onClick={onClick} className={`whitespace-nowrap border-b-2 px-4 py-2.5 text-sm font-semibold transition-colors ${active ? 'border-primary-600 text-primary-600' : 'border-transparent text-slate-500 hover:text-slate-700'}`}>
      {children}
    </button>
  );
}
