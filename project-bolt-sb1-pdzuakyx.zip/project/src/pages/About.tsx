import { HeartPulse, ShieldCheck, Award, Users, Clock, MapPin, Phone, Mail } from 'lucide-react';
import { Link } from '@/context/RouterContext';

export default function About() {
  return (
    <div>
      <section className="bg-gradient-to-b from-primary-50 to-white py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 rounded-full bg-accent-50 px-3 py-1.5 text-sm font-medium text-accent-700 ring-1 ring-accent-200">
              <HeartPulse className="h-4 w-4" />
              About MediSlot
            </div>
            <h1 className="mt-5 text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl">
              Caring for our community, one appointment at a time.
            </h1>
            <p className="mt-5 text-lg text-slate-600">
              MediSlot has served the community with compassionate, quality healthcare for over three decades. Our digital booking platform is designed to reduce waiting times and make accessing care simpler for every patient.
            </p>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard icon={<Users className="h-7 w-7" />} value="50,000+" label="Patients served" color="primary" />
          <StatCard icon={<ShieldCheck className="h-7 w-7" />} value="6" label="Specialist departments" color="accent" />
          <StatCard icon={<Award className="h-7 w-7" />} value="30+" label="Years of service" color="warm" />
          <StatCard icon={<Clock className="h-7 w-7" />} value="24/7" label="Online booking" color="primary" />
        </div>
      </section>

      <section className="bg-white py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-12 lg:grid-cols-2">
            <div>
              <h2 className="text-3xl font-bold text-slate-900">Our mission</h2>
              <p className="mt-4 text-slate-600">
                We believe healthcare should be accessible, organized, and stress-free. By digitizing appointment scheduling, we free up our doctors to focus on what matters most — patient care.
              </p>
              <p className="mt-4 text-slate-600">
                MediSlot connects patients with the right specialists, gives doctors control over their schedules, and provides administrators with the tools to keep everything running smoothly.
              </p>
              <Link to="/doctors" className="btn-primary mt-8">Find a Doctor</Link>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <img src="https://images.pexels.com/photos/263402/pexels-photo-263402.jpeg?auto=compress&cs=tinysrgb&w=600" alt="Hospital" className="h-64 w-full rounded-2xl object-cover shadow-sm" />
              <img src="https://images.pexels.com/photos/40568/medical-appointment-doctor-health-40568.jpeg?auto=compress&cs=tinysrgb&w=600" alt="Medical care" className="mt-8 h-64 w-full rounded-2xl object-cover shadow-sm" />
            </div>
          </div>
        </div>
      </section>

      <section className="bg-gradient-to-b from-white to-primary-50/50 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-center text-3xl font-bold text-slate-900">Visit us</h2>
          <div className="mt-10 grid grid-cols-1 gap-6 md:grid-cols-3">
            <InfoCard icon={<MapPin className="h-6 w-6" />} title="Address" lines={['MediSlot Health Center', 'Bengaluru 560001', 'Karnataka, India']} />
            <InfoCard icon={<Phone className="h-6 w-6" />} title="Phone" lines={['+91 80 4000 5000', 'Emergency: +91 80 4000 9111']} />
            <InfoCard icon={<Mail className="h-6 w-6" />} title="Email" lines={['care@medislot.app', 'appointments@medislot.app']} />
          </div>
        </div>
      </section>
    </div>
  );
}

function StatCard({ icon, value, label, color }: { icon: React.ReactNode; value: string; label: string; color: 'primary' | 'accent' | 'warm' }) {
  const c = { primary: 'bg-primary-50 text-primary-600', accent: 'bg-accent-50 text-accent-600', warm: 'bg-warm-50 text-warm-600' };
  return (
    <div className="card p-6 text-center">
      <div className={`mx-auto flex h-14 w-14 items-center justify-center rounded-2xl ${c[color]}`}>{icon}</div>
      <div className="mt-4 text-3xl font-extrabold text-slate-900">{value}</div>
      <div className="mt-1 text-sm text-slate-500">{label}</div>
    </div>
  );
}

function InfoCard({ icon, title, lines }: { icon: React.ReactNode; title: string; lines: string[] }) {
  return (
    <div className="card p-6">
      <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary-50 text-primary-600">{icon}</div>
      <h3 className="mt-4 font-semibold text-slate-900">{title}</h3>
      <div className="mt-2 space-y-1 text-sm text-slate-500">
        {lines.map((l) => <p key={l}>{l}</p>)}
      </div>
    </div>
  );
}
