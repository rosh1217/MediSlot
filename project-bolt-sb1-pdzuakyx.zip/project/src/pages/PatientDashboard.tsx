import { useEffect, useState } from 'react';
import { CalendarCheck, CalendarX, Clock, CalendarPlus, Activity, X, AlertCircle } from 'lucide-react';
import { Link } from '@/context/RouterContext';
import { useAuth } from '@/context/AuthContext';
import { supabase, type Appointment } from '@/lib/supabase';
import { formatDate, formatTime, formatCurrency, canCancel } from '@/lib/utils';

export default function PatientDashboard() {
  const { profile } = useAuth();
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [cancelTarget, setCancelTarget] = useState<Appointment | null>(null);
  const [cancelReason, setCancelReason] = useState('');
  const [cancelling, setCancelling] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function loadAppointments() {
    if (!profile) return;
    const { data } = await supabase
      .from('appointments')
      .select('*, doctor:doctor_profiles(*), department:departments(*)')
      .eq('patient_id', profile.id)
      .order('appointment_date', { ascending: false })
      .order('start_time', { ascending: false });
    setAppointments(data ?? []);
    setLoading(false);
  }

  useEffect(() => { loadAppointments(); }, [profile]);

  async function confirmCancel() {
    if (!cancelTarget) return;
    setCancelling(true);
    setError(null);
    const { error } = await supabase
      .from('appointments')
      .update({ status: 'cancelled', cancellation_reason: cancelReason || 'Cancelled by patient' })
      .eq('id', cancelTarget.id);
    if (error) { setError(error.message); setCancelling(false); return; }
    await supabase.from('appointment_slots').update({ status: 'available' }).eq('id', cancelTarget.slot_id);
    setCancelling(false);
    setCancelTarget(null);
    setCancelReason('');
    loadAppointments();
  }

  if (!profile) return null;

  const upcoming = appointments.filter((a) => a.status === 'booked' && new Date(`${a.appointment_date}T${a.start_time}`) >= new Date());
  const past = appointments.filter((a) => a.status === 'completed' || (a.status === 'booked' && new Date(`${a.appointment_date}T${a.start_time}`) < new Date()) || a.status === 'cancelled');
  const totalBookings = appointments.length;

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Welcome, {profile.full_name}</h1>
          <p className="mt-1 text-slate-500">Manage your appointments and health schedule.</p>
        </div>
        <Link to="/doctors" className="btn-primary">
          <CalendarPlus className="h-4 w-4" />
          Book Appointment
        </Link>
      </div>

      {/* Stats */}
      <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard icon={<CalendarCheck className="h-6 w-6" />} value={upcoming.length} label="Upcoming appointments" color="primary" />
        <StatCard icon={<Activity className="h-6 w-6" />} value={totalBookings} label="Total bookings" color="accent" />
        <StatCard icon={<CalendarX className="h-6 w-6" />} value={appointments.filter(a => a.status === 'cancelled').length} label="Cancelled" color="warm" />
      </div>

      {/* Upcoming */}
      <section className="mt-10">
        <h2 className="text-xl font-bold text-slate-900">Upcoming appointments</h2>
        {loading ? (
          <div className="mt-4 space-y-3">
            {[...Array(2)].map((_, i) => <div key={i} className="h-24 animate-pulse rounded-2xl bg-slate-100" />)}
          </div>
        ) : upcoming.length === 0 ? (
          <div className="card mt-4 p-8 text-center">
            <CalendarCheck className="mx-auto h-10 w-10 text-slate-300" />
            <p className="mt-3 text-slate-500">No upcoming appointments.</p>
            <Link to="/doctors" className="btn-primary mt-4">Book your first appointment</Link>
          </div>
        ) : (
          <div className="mt-4 space-y-3">
            {upcoming.map((appt) => (
              <AppointmentCard key={appt.id} appt={appt} onCancel={() => setCancelTarget(appt)} />
            ))}
          </div>
        )}
      </section>

      {/* History */}
      <section className="mt-10">
        <h2 className="text-xl font-bold text-slate-900">Appointment history</h2>
        {past.length === 0 ? (
          <p className="mt-4 text-sm text-slate-400">No past appointments yet.</p>
        ) : (
          <div className="mt-4 space-y-3">
            {past.map((appt) => (
              <AppointmentCard key={appt.id} appt={appt} onCancel={() => setCancelTarget(appt)} readonly />
            ))}
          </div>
        )}
      </section>

      {/* Cancel modal */}
      {cancelTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4 animate-fade-in" onClick={() => setCancelTarget(null)}>
          <div className="card max-w-md p-6 shadow-xl animate-scale-in" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-start justify-between">
              <h3 className="text-lg font-bold text-slate-900">Cancel appointment?</h3>
              <button onClick={() => setCancelTarget(null)} className="text-slate-400 hover:text-slate-600"><X className="h-5 w-5" /></button>
            </div>
            <p className="mt-2 text-sm text-slate-500">
              {cancelTarget.doctor?.full_name} on {formatDate(cancelTarget.appointment_date)} at {formatTime(cancelTarget.start_time)}
            </p>
            {canCancel(cancelTarget.appointment_date, cancelTarget.start_time) ? (
              <>
                <div className="mt-4">
                  <label className="label">Reason (optional)</label>
                  <input className="input" placeholder="e.g. schedule conflict" value={cancelReason} onChange={(e) => setCancelReason(e.target.value)} />
                </div>
                {error && <div className="mt-3 flex items-center gap-2 text-sm text-red-600"><AlertCircle className="h-4 w-4" />{error}</div>}
                <div className="mt-6 flex gap-3">
                  <button onClick={() => setCancelTarget(null)} className="btn-outline flex-1">Keep appointment</button>
                  <button onClick={confirmCancel} disabled={cancelling} className="btn-warm flex-1">
                    {cancelling ? <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" /> : 'Confirm cancel'}
                  </button>
                </div>
              </>
            ) : (
              <>
                <p className="mt-4 rounded-lg bg-warm-50 p-3 text-sm text-warm-700">
                  This appointment is within 2 hours and can no longer be cancelled online. Please contact the hospital directly.
                </p>
                <button onClick={() => setCancelTarget(null)} className="btn-outline mt-4 w-full">Close</button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function StatCard({ icon, value, label, color }: { icon: React.ReactNode; value: number; label: string; color: 'primary' | 'accent' | 'warm' }) {
  const c = { primary: 'bg-primary-50 text-primary-600', accent: 'bg-accent-50 text-accent-600', warm: 'bg-warm-50 text-warm-600' };
  return (
    <div className="card flex items-center gap-4 p-5">
      <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${c[color]}`}>{icon}</div>
      <div>
        <div className="text-2xl font-extrabold text-slate-900">{value}</div>
        <div className="text-sm text-slate-500">{label}</div>
      </div>
    </div>
  );
}

function AppointmentCard({ appt, onCancel, readonly }: { appt: Appointment; onCancel: () => void; readonly?: boolean }) {
  const statusColors = {
    booked: 'bg-accent-50 text-accent-700',
    cancelled: 'bg-red-50 text-red-600',
    completed: 'bg-primary-50 text-primary-700',
  };
  const canCancelAppt = appt.status === 'booked' && canCancel(appt.appointment_date, appt.start_time);

  return (
    <div className="card p-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex items-start gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary-50 text-primary-600">
            <Clock className="h-6 w-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-semibold text-slate-900">{appt.doctor?.full_name}</h3>
              <span className={`badge ${statusColors[appt.status]}`}>{appt.status}</span>
            </div>
            <p className="text-sm text-slate-500">{appt.doctor?.specialization} · {appt.department?.name}</p>
            <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-sm text-slate-600">
              <span>{formatDate(appt.appointment_date)}</span>
              <span>{formatTime(appt.start_time)} – {formatTime(appt.end_time)}</span>
              <span className="font-medium">{formatCurrency(appt.consultation_fee)}</span>
            </div>
            <div className="mt-1 text-xs text-slate-400">Ref: {appt.booking_reference}</div>
          </div>
        </div>
        {!readonly && canCancelAppt && (
          <button onClick={onCancel} className="btn-ghost text-red-600 hover:bg-red-50">
            <CalendarX className="h-4 w-4" />
            Cancel
          </button>
        )}
      </div>
    </div>
  );
}
