import { useState } from 'react';
import { Search, CalendarCheck, Clock, HeartPulse, ShieldCheck, ArrowRight, Stethoscope, UserRound, CalendarDays, Sparkles } from 'lucide-react';
import { Link, useRouter } from '@/context/RouterContext';
import { useEffect } from 'react';
import { supabase, type Department, type DoctorProfile } from '@/lib/supabase';
import { getDepartmentIcon } from '@/lib/icons';

export default function Home() {
  const { navigate } = useRouter();
  const [search, setSearch] = useState('');
  const [deptFilter, setDeptFilter] = useState('');
  const [departments, setDepartments] = useState<Department[]>([]);
  const [topDoctors, setTopDoctors] = useState<DoctorProfile[]>([]);

  useEffect(() => {
    supabase.from('departments').select('*').eq('active', true).order('name').then(({ data }) => setDepartments(data ?? []));
    supabase
      .from('doctor_profiles')
      .select('*, department:departments(*)')
      .eq('active', true)
      .limit(4)
      .then(({ data }) => setTopDoctors(data ?? []));
  }, []);

  function handleSearch() {
    const params = new URLSearchParams();
    if (search) params.set('q', search);
    if (deptFilter) params.set('dept', deptFilter);
    navigate('/doctors' + (params.toString() ? '?' + params.toString() : ''));
  }

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-b from-primary-50 via-white to-white">
        <div className="absolute inset-0 -z-10">
          <div className="absolute -left-20 top-10 h-72 w-72 rounded-full bg-primary-100/60 blur-3xl" />
          <div className="absolute right-0 top-40 h-80 w-80 rounded-full bg-accent-100/50 blur-3xl" />
        </div>
        <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <div className="animate-fade-up">
              <div className="inline-flex items-center gap-2 rounded-full bg-accent-50 px-3 py-1.5 text-sm font-medium text-accent-700 ring-1 ring-accent-200">
                <Sparkles className="h-4 w-4" />
                Now accepting online bookings
              </div>
              <h1 className="mt-5 text-4xl font-extrabold leading-tight tracking-tight text-slate-900 sm:text-5xl lg:text-6xl">
                Your health deserves a <span className="text-primary-600">simpler schedule.</span>
              </h1>
              <p className="mt-5 max-w-xl text-lg text-slate-600">
                Find the right doctor, choose a convenient time, and book your hospital appointment without unnecessary waiting.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link to="/doctors" className="btn-primary text-base">
                  <Search className="h-5 w-5" />
                  Find a Doctor
                </Link>
                <Link to="/about" className="btn-outline text-base">
                  How It Works
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
              <div className="mt-10 flex flex-wrap items-center gap-x-8 gap-y-3">
                <Stat icon={<Stethoscope className="h-5 w-5 text-primary-600" />} value="6+" label="Specialist doctors" />
                <Stat icon={<ShieldCheck className="h-5 w-5 text-accent-600" />} value="6" label="Departments" />
                <Stat icon={<CalendarCheck className="h-5 w-5 text-warm-500" />} value="24/7" label="Online booking" />
              </div>
            </div>

            {/* Quick search card */}
            <div className="animate-fade-up lg:delay-100">
              <div className="card p-6 shadow-lg sm:p-8">
                <h3 className="text-lg font-bold text-slate-900">Quick doctor search</h3>
                <p className="mt-1 text-sm text-slate-500">Find the right specialist in seconds.</p>
                <div className="mt-5 space-y-4">
                  <div>
                    <label className="label">Doctor name or specialization</label>
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                      <input
                        className="input pl-10"
                        placeholder="e.g. Cardiology, Dr. Sarah"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="label">Department</label>
                    <select className="input" value={deptFilter} onChange={(e) => setDeptFilter(e.target.value)}>
                      <option value="">All departments</option>
                      {departments.map((d) => (
                        <option key={d.id} value={d.id}>{d.name}</option>
                      ))}
                    </select>
                  </div>
                  <button onClick={handleSearch} className="btn-primary w-full">
                    <Search className="h-4 w-4" />
                    Find Doctors
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Specializations */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-slate-900">Our Specializations</h2>
          <p className="mt-2 text-slate-500">Comprehensive care across key medical departments.</p>
        </div>
        <div className="mt-10 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {departments.map((dept, i) => {
            const Icon = getDepartmentIcon(dept.icon);
            return (
              <Link
                key={dept.id}
                to={`/doctors?dept=${dept.id}`}
                className="card group p-6 hover:-translate-y-1 hover:border-primary-300 hover:shadow-md"
                style={{ animationDelay: `${i * 50}ms` }}
              >
                <div className="flex items-start gap-4">
                  <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary-50 text-primary-600 transition-colors group-hover:bg-primary-600 group-hover:text-white">
                    <Icon className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-900">{dept.name}</h3>
                    <p className="mt-1 text-sm text-slate-500">{dept.description}</p>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </section>

      {/* How it works */}
      <section className="bg-gradient-to-b from-white to-primary-50/50 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-slate-900">How it works</h2>
            <p className="mt-2 text-slate-500">Book in three simple steps.</p>
          </div>
          <div className="mt-12 grid grid-cols-1 gap-8 md:grid-cols-3">
            <StepCard step="1" icon={<UserRound className="h-7 w-7" />} title="Find your doctor" desc="Search by name, specialization, or department to discover the right specialist." color="primary" />
            <StepCard step="2" icon={<CalendarDays className="h-7 w-7" />} title="Choose an available slot" desc="View real-time availability and pick a time that works for you." color="accent" />
            <StepCard step="3" icon={<CalendarCheck className="h-7 w-7" />} title="Confirm your appointment" desc="Get an instant booking reference and manage your appointments anytime." color="warm" />
          </div>
        </div>
      </section>

      {/* Featured doctors */}
      {topDoctors.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
          <div className="flex items-end justify-between">
            <div>
              <h2 className="text-3xl font-bold text-slate-900">Meet our doctors</h2>
              <p className="mt-2 text-slate-500">Experienced specialists ready to help.</p>
            </div>
            <Link to="/doctors" className="btn-outline hidden sm:inline-flex">
              View all
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {topDoctors.map((doc) => (
              <Link key={doc.id} to={`/doctors/${doc.id}`} className="card group overflow-hidden hover:-translate-y-1 hover:shadow-md">
                <div className="aspect-[4/3] overflow-hidden bg-slate-100">
                  {doc.photo_url ? (
                    <img src={doc.photo_url} alt={doc.full_name} className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" />
                  ) : (
                    <div className="flex h-full items-center justify-center text-slate-300"><Stethoscope className="h-12 w-12" /></div>
                  )}
                </div>
                <div className="p-4">
                  <h3 className="font-semibold text-slate-900">{doc.full_name}</h3>
                  <p className="text-sm text-primary-600">{doc.specialization}</p>
                  <p className="mt-1 text-xs text-slate-400">{doc.department?.name}</p>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* Trust & convenience */}
      <section className="bg-white py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <div className="relative">
              <div className="absolute -inset-4 rounded-3xl bg-gradient-to-br from-primary-100 to-accent-100 opacity-50 blur-2xl" />
              <div className="relative grid grid-cols-2 gap-4">
                <FeatureMini icon={<Clock className="h-6 w-6" />} title="Convenient booking" desc="Book anytime, from anywhere." />
                <FeatureMini icon={<CalendarCheck className="h-6 w-6" />} title="Clear info" desc="See fees and availability upfront." />
                <FeatureMini icon={<Stethoscope className="h-6 w-6" />} title="Organized schedules" desc="Doctors manage their own slots." />
                <FeatureMini icon={<ShieldCheck className="h-6 w-6" />} title="Easy management" desc="Cancel or track with one click." />
              </div>
            </div>
            <div>
              <h2 className="text-3xl font-bold text-slate-900">Less waiting. Better care.</h2>
              <p className="mt-4 text-lg text-slate-600">
                MediSlot brings together patients, doctors, and hospital administration on one platform — making appointment booking effortless and reliable.
              </p>
              <ul className="mt-6 space-y-3">
                {['Real-time slot availability', 'Instant booking confirmation', 'Secure and private', 'Works on any device'].map((f) => (
                  <li key={f} className="flex items-center gap-3 text-slate-700">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-accent-100 text-accent-600">
                      <HeartPulse className="h-4 w-4" />
                    </span>
                    {f}
                  </li>
                ))}
              </ul>
              <Link to="/register" className="btn-accent mt-8">
                Get started today
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function Stat({ icon, value, label }: { icon: React.ReactNode; value: string; label: string }) {
  return (
    <div className="flex items-center gap-2">
      {icon}
      <div>
        <div className="text-lg font-bold text-slate-900">{value}</div>
        <div className="text-xs text-slate-400">{label}</div>
      </div>
    </div>
  );
}

function StepCard({ step, icon, title, desc, color }: { step: string; icon: React.ReactNode; title: string; desc: string; color: 'primary' | 'accent' | 'warm' }) {
  const colorMap = {
    primary: 'bg-primary-50 text-primary-600 ring-primary-200',
    accent: 'bg-accent-50 text-accent-600 ring-accent-200',
    warm: 'bg-warm-50 text-warm-600 ring-warm-200',
  };
  return (
    <div className="relative rounded-2xl border border-slate-200 bg-white p-8 text-center shadow-sm">
      <div className={`mx-auto flex h-16 w-16 items-center justify-center rounded-2xl ring-1 ${colorMap[color]}`}>
        {icon}
      </div>
      <div className="absolute right-5 top-5 text-5xl font-extrabold text-slate-100">{step}</div>
      <h3 className="mt-5 text-lg font-bold text-slate-900">{title}</h3>
      <p className="mt-2 text-sm text-slate-500">{desc}</p>
    </div>
  );
}

function FeatureMini({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary-50 text-primary-600">{icon}</div>
      <h4 className="mt-3 font-semibold text-slate-900">{title}</h4>
      <p className="mt-1 text-sm text-slate-500">{desc}</p>
    </div>
  );
}
