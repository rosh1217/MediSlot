import { useState } from 'react';
import { MapPin, Phone, Mail, Clock, Send, CheckCircle2 } from 'lucide-react';

export default function Contact() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSent(true);
    setForm({ name: '', email: '', subject: '', message: '' });
    setTimeout(() => setSent(false), 5000);
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-slate-900">Get in touch</h1>
        <p className="mt-3 text-lg text-slate-500">We're here to help. Reach out with any questions or feedback.</p>
      </div>

      <div className="mt-12 grid gap-8 lg:grid-cols-3">
        <div className="space-y-4">
          <ContactInfoCard icon={<MapPin className="h-6 w-6" />} title="Address" lines={['MediSlot Health Center', 'Bengaluru 560001']} />
          <ContactInfoCard icon={<Phone className="h-6 w-6" />} title="Phone" lines={['+91 80 4000 5000', 'Emergency: +91 80 4000 9111']} />
          <ContactInfoCard icon={<Mail className="h-6 w-6" />} title="Email" lines={['care@medislot.app']} />
          <ContactInfoCard icon={<Clock className="h-6 w-6" />} title="Hours" lines={['OPD: Mon–Sat, 8 AM – 8 PM', 'Emergency: 24/7']} />
        </div>

        <div className="lg:col-span-2">
          <div className="card p-8">
            {sent && (
              <div className="mb-6 flex items-center gap-3 rounded-xl bg-accent-50 p-4 text-accent-700 animate-fade-in">
                <CheckCircle2 className="h-5 w-5" />
                Thank you! Your message has been sent. We'll get back to you soon.
              </div>
            )}
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid gap-5 sm:grid-cols-2">
                <div>
                  <label className="label">Your name</label>
                  <input required className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                </div>
                <div>
                  <label className="label">Email</label>
                  <input type="email" required className="input" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
                </div>
              </div>
              <div>
                <label className="label">Subject</label>
                <input required className="input" value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} />
              </div>
              <div>
                <label className="label">Message</label>
                <textarea required rows={5} className="input resize-none" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} />
              </div>
              <button type="submit" className="btn-primary">
                <Send className="h-4 w-4" />
                Send message
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

function ContactInfoCard({ icon, title, lines }: { icon: React.ReactNode; title: string; lines: string[] }) {
  return (
    <div className="card flex items-start gap-4 p-5">
      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary-50 text-primary-600">{icon}</div>
      <div>
        <h3 className="font-semibold text-slate-900">{title}</h3>
        <div className="mt-1 space-y-0.5 text-sm text-slate-500">
          {lines.map((l) => <p key={l}>{l}</p>)}
        </div>
      </div>
    </div>
  );
}
