import { useEffect, useState } from 'react';
import { CalendarDays, Clock, CheckCircle2, XCircle, CalendarPlus, Users, Activity, Trash2 } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { supabase, type Appointment, type DoctorProfile, type Slot } from '@/lib/supabase';
import { formatDate, formatTime, next7Days } from '@/lib/utils';

export default function DoctorDashboard() {
  const { profile } = useAuth();
  const [doctor, setDoctor] = useState<DoctorProfile | null>(null);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [slots, setSlots] = useState<Slot[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'schedule' | 'availability'>('schedule');
  const [slotDate, setSlotDate] = useState(next7Days()[0].value);
  const [slotStart, setSlotStart] = useState('09:00');
  const [slotEnd, setSlotEnd] = useState('09:30');
  const [addingSlot, setAddingSlot] = useState(false);

  async function loadDoctor() {
    if (!profile) return;
    const { data } = await supabase.from('doctor_profiles').select('*, department:departments(*)').eq('user_id', profile.id).maybeSingle();
    setDoctor(data as DoctorProfile | null);
    return data?.id;
  }

  async function loadAppointments(docId: string) {
    const { data } = await supabase
      .from('appointments')
      .select('*, patient:profiles!appointments_patient_id_fkey(*), department:departments(*)')
      .eq('doctor_id', docId)
      .order('appointment_date', { ascending: false })
      .order('start_time', { ascending: false });
    setAppointments(data ?? []);
  }

  async function loadSlots(docId: string) {
    const { data } = await supabase
      .from('appointment_slots')
      .select('*')
      .eq('doctor_id', docId)
      .gte('appointment_date', new Date().toISOString().slice(0, 10))
      .order('appointment_date')
      .order('start_time');
    setSlots(data ?? []);
    setLoading(false);
  }

  useEffect(() => {
    (async () => {
      const doc = await loadDoctor();
      if (doc?.id) {
        await Promise.all([loadAppointments(doc.id), loadSlots(doc.id)]);
      } else {
        setLoading(false);
      }
    })();
  }, [profile]);

  async function updateStatus(appt: Appointment, status: 'completed' | 'cancelled') {
    await supabase.from('appointments').update({ status }).eq('id', appt.id);
    if (status === 'cancelled') {
      await supabase.from('appointment_slots').update({ status: 'available' }).eq('id', appt.slot_id);
    }
    if (doctor) loadAppointments(doctor.id);
  }

  async function addSlot() {
    if (!doctor) return;
    setAddingSlot(true);
    await supabase.from('appointment_slots').insert({
      doctor_id: doctor.id,
      appointment_date: slotDate,
      start_time: slotStart,
      end_time: slotEnd,
      status: 'available',
    });
    setAddingSlot(false);
    loadSlots(doctor.id);
  }

  async function deleteSlot(slotId: string) {
    if (!doctor) return;
    await supabase.from('appointment_slots').delete().eq('id', slotId);
    loadSlots(doctor.id);
  }

  if (loading) {
    return <div className="flex min-h-[60vh] items-center justify-center"><div className="h-8 w-8 animate-spin rounded-full border-3 border-primary-200 border-t-primary-600" /></div>;
  }

  if (!doctor) {
    return <div className="mx-auto max-w-3xl px-4 py-16 text-center"><h1 className="text-2xl font-bold text-slate-900">No doctor profile linked to your account.</h1><p className="mt-2 text-slate-500">Please contact an administrator.</p></div>;
  }

  const today = new Date().toISOString().slice(0, 10);
  const todaysAppts = appointments.filter((a) => a.appointment_date === today && a.status === 'booked');
  const upcomingAppts = appointments.filter((a) => a.appointment_date > today && a.status === 'booked');
  const completedAppts = appointments.filter((a) => a.status === 'completed');
  const dateSlots = slots.filter((s) => s.appointment_date === slotDate);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">{doctor.full_name}</h1>
          <p className="mt-1 text-slate-500">{doctor.specialization} · {doctor.department?.name}</p>
        </div>
      </div>

      {/* Stats */}
      <div className="mt-8 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard icon={<CalendarDays className="h-6 w-6" />} value={todaysAppts.length} label="Today" color="primary" />
        <StatCard icon={<Clock className="h-6 w-6" />} value={upcomingAppts.length} label="Upcoming" color="accent" />
        <StatCard icon={<CheckCircle2 className="h-6 w-6" />} value={completedAppts.length} label="Completed" color="primary" />
        <StatCard icon={<Users className="h-6 w-6" />} value={appointments.length} label="Total patients" color="warm" />
      </div>

      {/* Tabs */}
      <div className="mt-8 flex gap-1 border-b border-slate-200">
        <TabBtn active={tab === 'schedule'} onClick={() => setTab('schedule')}>Appointments</TabBtn>
        <TabBtn active={tab === 'availability'} onClick={() => setTab('availability')}>Manage Availability</TabBtn>
      </div>

      {tab === 'schedule' && (
        <div className="mt-6 space-y-6">
          <section>
            <h2 className="text-lg font-bold text-slate-900">Today's appointments</h2>
            {todaysAppts.length === 0 ? (
              <div className="card mt-3 p-6 text-center text-sm text-slate-400">No appointments today.</div>
            ) : (
              <div className="mt-3 space-y-3">
                {todaysAppts.map((a) => <DocApptCard key={a.id} appt={a} onUpdate={updateStatus} />)}
              </div>
            )}
          </section>
          <section>
            <h2 className="text-lg font-bold text-slate-900">Upcoming</h2>
            {upcomingAppts.length === 0 ? (
              <div className="card mt-3 p-6 text-center text-sm text-slate-400">No upcoming appointments.</div>
            ) : (
              <div className="mt-3 space-y-3">
                {upcomingAppts.map((a) => <DocApptCard key={a.id} appt={a} onUpdate={updateStatus} />)}
              </div>
            )}
          </section>
          <section>
            <h2 className="text-lg font-bold text-slate-900">History</h2>
            <div className="mt-3 space-y-3">
              {appointments.filter(a => a.status === 'completed' || a.status === 'cancelled').map((a) => <DocApptCard key={a.id} appt={a} readonly />)}
              {appointments.filter(a => a.status === 'completed' || a.status === 'cancelled').length === 0 && <div className="card p-6 text-center text-sm text-slate-400">No history yet.</div>}
            </div>
          </section>
        </div>
      )}

      {tab === 'availability' && (
        <div className="mt-6">
          <div className="card p-6">
            <h2 className="text-lg font-bold text-slate-900">Add a new slot</h2>
            <div className="mt-4 grid gap-4 sm:grid-cols-4">
              <div>
                <label className="label">Date</label>
                <select className="input" value={slotDate} onChange={(e) => setSlotDate(e.target.value)}>
                  {next7Days().map((d) => <option key={d.value} value={d.value}>{d.label} · {d.sub}</option>)}
                </select>
              </div>
              <div>
                <label className="label">Start time</label>
                <input type="time" className="input" value={slotStart} onChange={(e) => setSlotStart(e.target.value)} />
              </div>
              <div>
                <label className="label">End time</label>
                <input type="time" className="input" value={slotEnd} onChange={(e) => setSlotEnd(e.target.value)} />
              </div>
              <div className="flex items-end">
                <button onClick={addSlot} disabled={addingSlot} className="btn-primary w-full">
                  <CalendarPlus className="h-4 w-4" />
                  {addingSlot ? 'Adding...' : 'Add slot'}
                </button>
              </div>
            </div>
          </div>

          <div className="mt-6 card p-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-slate-900">Slots for {formatDate(slotDate)}</h2>
              <span className="text-sm text-slate-400">{dateSlots.length} slot(s)</span>
            </div>
            <div className="mt-4 space-y-2">
              {dateSlots.length === 0 ? (
                <p className="text-sm text-slate-400">No slots for this date. Add one above.</p>
              ) : dateSlots.map((slot) => (
                <div key={slot.id} className="flex items-center justify-between rounded-xl border border-slate-200 p-3">
                  <div className="flex items-center gap-3">
                    <Clock className="h-4 w-4 text-slate-400" />
                    <span className="text-sm font-medium text-slate-700">{formatTime(slot.start_time)} – {formatTime(slot.end_time)}</span>
                    <span className={`badge ${slot.status === 'available' ? 'bg-accent-50 text-accent-700' : slot.status === 'booked' ? 'bg-primary-50 text-primary-700' : 'bg-slate-100 text-slate-500'}`}>
                      {slot.status}
                    </span>
                  </div>
                  {slot.status === 'available' && (
                    <button onClick={() => deleteSlot(slot.id)} className="btn-ghost text-red-600 hover:bg-red-50">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function StatCard({ icon, value, label, color }: { icon: React.ReactNode; value: number; label: string; color: 'primary' | 'accent' | 'warm' }) {
  const c = { primary: 'bg-primary-50 text-primary-600', accent: 'bg-accent-50 text-accent-600', warm: 'bg-warm-50 text-warm-600' };
  return (
    <div className="card flex items-center gap-3 p-4">
      <div className={`flex h-11 w-11 items-center justify-center rounded-xl ${c[color]}`}>{icon}</div>
      <div>
        <div className="text-2xl font-extrabold text-slate-900">{value}</div>
        <div className="text-xs text-slate-500">{label}</div>
      </div>
    </div>
  );
}

function TabBtn({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`border-b-2 px-4 py-2.5 text-sm font-semibold transition-colors ${
        active ? 'border-primary-600 text-primary-600' : 'border-transparent text-slate-500 hover:text-slate-700'
      }`}
    >
      {children}
    </button>
  );
}

function DocApptCard({ appt, onUpdate, readonly }: { appt: Appointment; onUpdate?: (a: Appointment, s: 'completed' | 'cancelled') => void; readonly?: boolean }) {
  const statusColors = {
    booked: 'bg-accent-50 text-accent-700',
    cancelled: 'bg-red-50 text-red-600',
    completed: 'bg-primary-50 text-primary-700',
  };
  return (
    <div className="card p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="font-semibold text-slate-900">{appt.patient?.full_name}</h3>
            <span className={`badge ${statusColors[appt.status]}`}>{appt.status}</span>
          </div>
          <p className="text-sm text-slate-500">{appt.patient?.phone}</p>
          <div className="mt-1 flex gap-x-4 text-sm text-slate-600">
            <span>{formatDate(appt.appointment_date)}</span>
            <span>{formatTime(appt.start_time)} – {formatTime(appt.end_time)}</span>
          </div>
          {appt.patient_notes && <p className="mt-1 text-xs text-slate-400">Notes: {appt.patient_notes}</p>}
          <p className="mt-1 text-xs text-slate-400">Ref: {appt.booking_reference}</p>
        </div>
        {!readonly && appt.status === 'booked' && onUpdate && (
          <div className="flex gap-2">
            <button onClick={() => onUpdate(appt, 'completed')} className="btn-ghost text-accent-600 hover:bg-accent-50">
              <CheckCircle2 className="h-4 w-4" />
              Complete
            </button>
            <button onClick={() => onUpdate(appt, 'cancelled')} className="btn-ghost text-red-600 hover:bg-red-50">
              <XCircle className="h-4 w-4" />
              Cancel
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
