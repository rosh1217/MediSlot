import { LucideIcon } from 'lucide-react';
import { HeartPulse, Shield, Baby, Brain, Stethoscope, Bone } from 'lucide-react';

const iconMap: Record<string, LucideIcon> = {
  HeartPulse,
  Shield,
  Baby,
  Brain,
  Stethoscope,
  Bone,
};

export function getDepartmentIcon(name: string | null): LucideIcon {
  if (!name) return Stethoscope;
  return iconMap[name] ?? Stethoscope;
}
