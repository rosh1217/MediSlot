import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

export type Role = 'patient' | 'doctor' | 'admin';

export interface Profile {
  id: string;
  full_name: string;
  phone: string | null;
  role: Role;
  active: boolean;
}

export interface Department {
  id: string;
  name: string;
  description: string | null;
  icon: string | null;
  active: boolean;
}

export interface DoctorProfile {
  id: string;
  user_id: string | null;
  department_id: string | null;
  full_name: string;
  qualification: string | null;
  specialization: string | null;
  experience_years: number;
  consultation_fee: number;
  biography: string | null;
  photo_url: string | null;
  active: boolean;
  department?: Department | null;
}

export interface Slot {
  id: string;
  doctor_id: string;
  appointment_date: string;
  start_time: string;
  end_time: string;
  status: 'available' | 'booked' | 'blocked';
}

export interface Appointment {
  id: string;
  booking_reference: string;
  patient_id: string;
  doctor_id: string;
  slot_id: string;
  department_id: string | null;
  appointment_date: string;
  start_time: string;
  end_time: string;
  consultation_fee: number;
  status: 'booked' | 'cancelled' | 'completed';
  cancellation_reason: string | null;
  patient_notes: string | null;
  created_at: string;
  doctor?: DoctorProfile | null;
  patient?: Profile | null;
  department?: Department | null;
}
