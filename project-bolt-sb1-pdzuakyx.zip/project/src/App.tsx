import { AuthProvider } from '@/context/AuthContext';
import { RouterProvider, useRouter } from '@/context/RouterContext';
import Layout from '@/components/Layout';
import Chatbot from '@/components/Chatbot';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import Home from '@/pages/Home';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import About from '@/pages/About';
import Contact from '@/pages/Contact';
import Departments from '@/pages/Departments';
import DoctorDirectory from '@/pages/DoctorDirectory';
import DoctorProfilePage from '@/pages/DoctorProfilePage';
import PatientDashboard from '@/pages/PatientDashboard';
import DoctorDashboard from '@/pages/DoctorDashboard';
import AdminDashboard from '@/pages/AdminDashboard';

function Routes() {
  const { path } = useRouter();
  const cleanPath = path.split('?')[0];

  if (cleanPath === '/' || cleanPath === '') return <Home />;
  if (cleanPath === '/login') return <Login />;
  if (cleanPath === '/register') return <Register />;
  if (cleanPath === '/about') return <About />;
  if (cleanPath === '/contact') return <Contact />;
  if (cleanPath === '/departments') return <Departments />;
  if (cleanPath === '/doctors') return <DoctorDirectory />;
  if (cleanPath.startsWith('/doctors/')) {
    const id = cleanPath.split('/')[2];
    return <DoctorProfilePage doctorId={id} />;
  }
  if (cleanPath === '/patient/dashboard')
    return <ProtectedRoute roles={['patient']}><PatientDashboard /></ProtectedRoute>;
  if (cleanPath === '/doctor/dashboard')
    return <ProtectedRoute roles={['doctor']}><DoctorDashboard /></ProtectedRoute>;
  if (cleanPath === '/admin/dashboard')
    return <ProtectedRoute roles={['admin']}><AdminDashboard /></ProtectedRoute>;

  return (
    <div className="mx-auto max-w-3xl px-4 py-20 text-center">
      <h1 className="text-4xl font-bold text-slate-900">404</h1>
      <p className="mt-3 text-slate-500">Page not found.</p>
      <a href="#/" className="btn-primary mt-6">Go home</a>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <RouterProvider>
        <Layout>
          <Routes />
        </Layout>
        <Chatbot />
      </RouterProvider>
    </AuthProvider>
  );
}

export default App;
