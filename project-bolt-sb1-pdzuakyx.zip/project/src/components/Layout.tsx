import { useState, type ReactNode } from 'react';
import { HeartPulse, Menu, X, LogOut, LayoutDashboard, User, Stethoscope, Shield } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { Link, useRouter } from '@/context/RouterContext';

export default function Layout({ children }: { children: ReactNode }) {
  const { profile, signOut } = useAuth();
  const { navigate } = useRouter();
  const [menuOpen, setMenuOpen] = useState(false);

  const navLinks = [
    { label: 'Home', to: '/' },
    { label: 'Find a Doctor', to: '/doctors' },
    { label: 'Departments', to: '/departments' },
    { label: 'About', to: '/about' },
    { label: 'Contact', to: '/contact' },
  ];

  function dashboardLink() {
    if (!profile) return null;
    if (profile.role === 'patient') return { label: 'My Dashboard', to: '/patient/dashboard', icon: <LayoutDashboard className="h-4 w-4" /> };
    if (profile.role === 'doctor') return { label: 'Doctor Dashboard', to: '/doctor/dashboard', icon: <Stethoscope className="h-4 w-4" /> };
    if (profile.role === 'admin') return { label: 'Admin Panel', to: '/admin/dashboard', icon: <Shield className="h-4 w-4" /> };
    return null;
  }

  const dash = dashboardLink();

  function handleSignOut() {
    signOut();
    navigate('/');
    setMenuOpen(false);
  }

  return (
    <div className="flex min-h-screen flex-col bg-slate-50">
      <header className="sticky top-0 z-40 border-b border-slate-200 bg-white/90 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
          <Link to="/" className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary-500 to-primary-700 text-white shadow-sm">
              <HeartPulse className="h-5 w-5" />
            </div>
            <div className="leading-tight">
              <span className="block text-base font-bold text-slate-900">MediSlot</span>
              <span className="block text-[11px] font-medium text-primary-600">Less waiting. Better care.</span>
            </div>
          </Link>

          <nav className="hidden items-center gap-1 md:flex">
            {navLinks.map((l) => (
              <Link key={l.to} to={l.to} className="rounded-lg px-3 py-2 text-sm font-medium text-slate-600 transition-colors hover:bg-primary-50 hover:text-primary-700">
                {l.label}
              </Link>
            ))}
          </nav>

          <div className="hidden items-center gap-2 md:flex">
            {profile && dash ? (
              <>
                <Link to={dash.to} className="btn-outline">
                  {dash.icon}
                  {dash.label}
                </Link>
                <button onClick={handleSignOut} className="btn-ghost" title="Sign out">
                  <LogOut className="h-4 w-4" />
                  Sign out
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="btn-ghost">
                  <User className="h-4 w-4" />
                  Sign in
                </Link>
                <Link to="/register" className="btn-primary">
                  Register
                </Link>
              </>
            )}
          </div>

          <button onClick={() => setMenuOpen((v) => !v)} className="rounded-lg p-2 text-slate-600 hover:bg-slate-100 md:hidden">
            {menuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

        {menuOpen && (
          <div className="border-t border-slate-200 bg-white px-4 py-3 md:hidden">
            <nav className="flex flex-col gap-1">
              {navLinks.map((l) => (
                <Link key={l.to} to={l.to} onClick={() => setMenuOpen(false)} className="rounded-lg px-3 py-2.5 text-sm font-medium text-slate-700 hover:bg-primary-50 hover:text-primary-700">
                  {l.label}
                </Link>
              ))}
              <div className="my-2 border-t border-slate-100" />
              {profile && dash ? (
                <>
                  <Link to={dash.to} onClick={() => setMenuOpen(false)} className="rounded-lg px-3 py-2.5 text-sm font-medium text-slate-700 hover:bg-primary-50">
                    {dash.label}
                  </Link>
                  <button onClick={handleSignOut} className="flex items-center gap-2 rounded-lg px-3 py-2.5 text-left text-sm font-medium text-slate-700 hover:bg-slate-100">
                    <LogOut className="h-4 w-4" /> Sign out
                  </button>
                </>
              ) : (
                <>
                  <Link to="/login" onClick={() => setMenuOpen(false)} className="rounded-lg px-3 py-2.5 text-sm font-medium text-slate-700 hover:bg-primary-50">Sign in</Link>
                  <Link to="/register" onClick={() => setMenuOpen(false)} className="rounded-lg px-3 py-2.5 text-sm font-semibold text-primary-700 hover:bg-primary-50">Register</Link>
                </>
              )}
            </nav>
          </div>
        )}
      </header>

      <main className="flex-1">{children}</main>

      <footer className="border-t border-slate-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
            <div className="md:col-span-1">
              <div className="flex items-center gap-2.5">
                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary-500 to-primary-700 text-white">
                  <HeartPulse className="h-5 w-5" />
                </div>
                <div>
                  <span className="block text-base font-bold text-slate-900">MediSlot</span>
                  <span className="block text-[11px] font-medium text-primary-600">Less waiting. Better care.</span>
                </div>
              </div>
              <p className="mt-4 text-sm text-slate-500">Book your hospital appointment in seconds — now accepting online bookings.</p>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-slate-900">Quick Links</h4>
              <ul className="mt-3 space-y-2 text-sm text-slate-500">
                <li><Link to="/doctors" className="hover:text-primary-600">Find a Doctor</Link></li>
                <li><Link to="/departments" className="hover:text-primary-600">Departments</Link></li>
                <li><Link to="/about" className="hover:text-primary-600">About Us</Link></li>
                <li><Link to="/contact" className="hover:text-primary-600">Contact</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-slate-900">Legal</h4>
              <ul className="mt-3 space-y-2 text-sm text-slate-500">
                <li><Link to="/privacy" className="hover:text-primary-600">Privacy Policy</Link></li>
                <li><Link to="/terms" className="hover:text-primary-600">Terms of Use</Link></li>
                <li><Link to="/login" className="hover:text-primary-600">Login</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-slate-900">Contact</h4>
              <ul className="mt-3 space-y-2 text-sm text-slate-500">
                <li>MediSlot Health Center, Bengaluru 560001</li>
                <li>+91 80 4000 5000</li>
                <li>care@medislot.app</li>
              </ul>
            </div>
          </div>
          <div className="mt-10 border-t border-slate-100 pt-6 text-center text-sm text-slate-400">
            © {new Date().getFullYear()} MediSlot. For demonstration purposes.
          </div>
        </div>
      </footer>
    </div>
  );
}
