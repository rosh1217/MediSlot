import { useEffect, type ReactNode } from 'react';
import { useRouter } from '@/context/RouterContext';
import { useAuth } from '@/context/AuthContext';
import type { Role } from '@/lib/supabase';

export function ProtectedRoute({ children, roles }: { children: ReactNode; roles?: Role[] }) {
  const { profile, loading } = useAuth();
  const { navigate } = useRouter();

  useEffect(() => {
    if (loading) return;
    if (!profile) {
      navigate('/login');
      return;
    }
    if (roles && !roles.includes(profile.role)) {
      navigate('/');
    }
  }, [profile, loading, roles, navigate]);

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-3 border-primary-200 border-t-primary-600" />
      </div>
    );
  }

  if (!profile || (roles && !roles.includes(profile.role))) {
    return null;
  }

  return <>{children}</>;
}
