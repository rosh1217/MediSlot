import { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Bot, Sparkles } from 'lucide-react';

interface Msg {
  role: 'bot' | 'user';
  text: string;
}

const quickPrompts = [
  'How do I book an appointment?',
  'What departments are available?',
  'How do I cancel an appointment?',
  'What are the hospital timings?',
];

const knowledge: { keywords: string[]; answer: string }[] = [
  {
    keywords: ['book', 'appointment', 'schedule', 'how do i book'],
    answer: "Booking an appointment is easy! Click 'Find a Doctor' in the navigation, browse or search for a specialist, open their profile, pick an available date and time slot, then confirm. You'll get a booking reference instantly. You need to be signed in as a patient to book.",
  },
  {
    keywords: ['cancel', 'cancellation'],
    answer: "You can cancel an appointment from your Patient Dashboard. Go to 'My Appointments', find the appointment, and click Cancel. Cancellations must be made at least 2 hours before the scheduled start time. If it's within 2 hours, please call the hospital directly at +91 80 4000 5000.",
  },
  {
    keywords: ['department', 'specialization', 'specialist', 'cardiology', 'dermatology', 'orthopedic', 'pediatric', 'neurology', 'general medicine'],
    answer: "MediSlot has 6 specialist departments: Cardiology (heart care), Dermatology (skin care), Orthopedics (bones & joints), Pediatrics (child health), Neurology (brain & nervous system), and General Medicine (primary care). Visit the Departments page to see available doctors in each.",
  },
  {
    keywords: ['timing', 'hours', 'open', 'when', 'time', 'closed'],
    answer: "Our OPD runs Monday to Saturday, 8 AM to 8 PM. Online booking is available 24/7. The Emergency department is open 24 hours, 7 days a week. Call +91 80 4000 9111 for emergencies.",
  },
  {
    keywords: ['doctor', 'find', 'search', 'specialist'],
    answer: "To find a doctor, use the search bar on the home page or go to 'Find a Doctor'. You can filter by department or search by the doctor's name or specialization. Each doctor's profile shows their qualifications, experience, consultation fee, and available time slots.",
  },
  {
    keywords: ['register', 'sign up', 'create account', 'account'],
    answer: "To register, click 'Register' in the navigation bar. Fill in your name, phone, email, and a password. Registration is for patients only. If you're a doctor or admin, your account is set up by the hospital administration.",
  },
  {
    keywords: ['login', 'sign in', 'password'],
    answer: "Click 'Sign in' in the navigation bar and enter your email and password. If you've forgotten your password, please contact the hospital. For demo purposes, you can use: patient@demo.com / patientpass123, dr.sarah@mgmhospital.com / doctorpass123, or admin@mgmhospital.com / adminpass123.",
  },
  {
    keywords: ['fee', 'cost', 'price', 'charge', 'pay'],
    answer: "Consultation fees vary by doctor and specialization. Each doctor's profile displays their consultation fee before booking. Fees typically range from ₹400 to ₹900. Payment is currently made at the hospital — online payment is coming soon.",
  },
  {
    keywords: ['mgm', 'hospital', 'address', 'location', 'where', 'contact', 'phone', 'email'],
    answer: "MediSlot Health Center is located in Bengaluru 560001, Karnataka. You can reach us at +91 80 4000 5000 or email care@medislot.app. The Emergency line is +91 80 4000 9111.",
  },
  {
    keywords: ['hello', 'hi', 'hey', 'greeting'],
    answer: "Hello! I'm the MediSlot assistant. I can help you with booking appointments, finding doctors, cancellation policies, hospital timings, and more. How can I help you today?",
  },
  {
    keywords: ['thank', 'thanks'],
    answer: "You're welcome! Is there anything else I can help you with?",
  },
];

function getAnswer(query: string): string {
  const q = query.toLowerCase();
  for (const item of knowledge) {
    if (item.keywords.some((kw) => q.includes(kw))) {
      return item.answer;
    }
  }
  return "I'm not sure about that, but I can help with booking appointments, finding doctors, cancellation policies, hospital timings, departments, and contact information. Try asking about one of those, or call us at +91 80 4000 5000.";
}

export default function Chatbot() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([
    { role: 'bot', text: "Hi! I'm the MediSlot assistant. How can I help you today?" },
  ]);
  const [input, setInput] = useState('');
  const [typing, setTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, typing]);

  function send(text: string) {
    if (!text.trim()) return;
    const userMsg: Msg = { role: 'user', text };
    setMessages((m) => [...m, userMsg]);
    setInput('');
    setTyping(true);
    setTimeout(() => {
      const answer = getAnswer(text);
      setMessages((m) => [...m, { role: 'bot', text: answer }]);
      setTyping(false);
    }, 600 + Math.random() * 400);
  }

  return (
    <>
      {/* Toggle button */}
      {!open && (
        <button
          onClick={() => setOpen(true)}
          className="fixed bottom-5 right-5 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-primary-600 text-white shadow-lg transition-all hover:bg-primary-700 hover:shadow-xl active:scale-95 animate-scale-in"
          aria-label="Open chat assistant"
        >
          <MessageCircle className="h-6 w-6" />
          <span className="absolute -top-1 -right-1 flex h-3 w-3">
            <span className="absolute h-full w-full animate-ping rounded-full bg-accent-400 opacity-75" />
            <span className="relative h-3 w-3 rounded-full bg-accent-500" />
          </span>
        </button>
      )}

      {/* Chat window */}
      {open && (
        <div className="fixed bottom-5 right-5 z-50 flex h-[min(560px,calc(100vh-40px))] w-[min(380px,calc(100vw-40px))] flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-2xl animate-scale-in">
          {/* Header */}
          <div className="flex items-center justify-between bg-gradient-to-r from-primary-600 to-primary-700 p-4 text-white">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/20">
                <Bot className="h-5 w-5" />
              </div>
              <div>
                <div className="flex items-center gap-1.5 text-sm font-bold">
                  MediSlot Assistant
                  <Sparkles className="h-3 w-3 text-accent-300" />
                </div>
                <div className="text-xs text-primary-100">Online · Typically replies instantly</div>
              </div>
            </div>
            <button onClick={() => setOpen(false)} className="rounded-lg p-1.5 transition-colors hover:bg-white/20">
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Messages */}
          <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto bg-slate-50 p-4">
            {messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-fade-in`}>
                <div
                  className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-sm ${
                    msg.role === 'user'
                      ? 'rounded-br-md bg-primary-600 text-white'
                      : 'rounded-bl-md bg-white text-slate-700 shadow-sm ring-1 ring-slate-100'
                  }`}
                >
                  {msg.text}
                </div>
              </div>
            ))}
            {typing && (
              <div className="flex justify-start animate-fade-in">
                <div className="rounded-2xl rounded-bl-md bg-white px-4 py-3 shadow-sm ring-1 ring-slate-100">
                  <div className="flex gap-1">
                    <span className="h-2 w-2 animate-bounce rounded-full bg-slate-300" style={{ animationDelay: '0ms' }} />
                    <span className="h-2 w-2 animate-bounce rounded-full bg-slate-300" style={{ animationDelay: '150ms' }} />
                    <span className="h-2 w-2 animate-bounce rounded-full bg-slate-300" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Quick prompts */}
          {messages.length <= 2 && (
            <div className="flex flex-wrap gap-2 border-t border-slate-100 bg-white px-3 pt-3">
              {quickPrompts.map((p) => (
                <button key={p} onClick={() => send(p)} className="rounded-full border border-primary-200 bg-primary-50 px-3 py-1.5 text-xs font-medium text-primary-700 transition-colors hover:bg-primary-100">
                  {p}
                </button>
              ))}
            </div>
          )}

          {/* Input */}
          <div className="flex items-center gap-2 border-t border-slate-100 bg-white p-3">
            <input
              className="flex-1 rounded-xl border border-slate-200 px-3.5 py-2.5 text-sm text-slate-800 placeholder-slate-400 focus:border-primary-500 focus:outline-none focus:ring-2 focus:ring-primary-100"
              placeholder="Type your message..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && send(input)}
            />
            <button onClick={() => send(input)} disabled={!input.trim()} className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary-600 text-white transition-colors hover:bg-primary-700 disabled:opacity-40">
              <Send className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}
    </>
  );
}
