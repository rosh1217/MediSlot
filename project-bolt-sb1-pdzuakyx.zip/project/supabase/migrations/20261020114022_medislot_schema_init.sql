/*
# MediSlot — Hospital Appointment Booking System

Creates the full schema for MediSlot: profiles, departments, doctor_profiles,
appointment_slots, and appointments, with role-based RLS and seed data for MGM Hospital.

1. New Tables
- profiles: extends auth.users with full_name, phone, role (patient/doctor/admin), active
- departments: hospital departments (Cardiology, etc.)
- doctor_profiles: doctor details linked to a user account and department
- appointment_slots: date/time slots a doctor offers, status available/booked/blocked
- appointments: a booked appointment referencing patient, doctor, slot, with booking reference

2. Security
- RLS enabled on all tables.
- profiles: self read/update; admins read all.
- departments & doctor_profiles: public read (anon+authenticated) so guests can browse; admin manage; doctors update own profile.
- appointment_slots: public read; doctors manage own; admin manage.
- appointments: patients see/cancel own; doctors see/update own; admin see all & manage.
- Helper SECURITY DEFINER functions is_admin() / is_doctor() for role checks in policies.

3. Seed Data (MGM Hospital)
- 6 departments.
- 1 admin, 6 doctors (linked to doctor_profiles), 1 sample patient — auth users created with bcrypt via pgcrypto.
- Appointment slots for each doctor over the next 7 days.
*/

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ---------- profiles ----------
CREATE TABLE IF NOT EXISTS public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  phone text,
  role text NOT NULL DEFAULT 'patient' CHECK (role IN ('patient','doctor','admin')),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- ---------- departments ----------
CREATE TABLE IF NOT EXISTS public.departments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  description text,
  icon text,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ---------- doctor_profiles ----------
CREATE TABLE IF NOT EXISTS public.doctor_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  department_id uuid REFERENCES public.departments(id) ON DELETE SET NULL,
  full_name text NOT NULL,
  qualification text,
  specialization text,
  experience_years int DEFAULT 0,
  consultation_fee numeric(10,2) DEFAULT 0,
  biography text,
  photo_url text,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ---------- appointment_slots ----------
CREATE TABLE IF NOT EXISTS public.appointment_slots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  doctor_id uuid NOT NULL REFERENCES public.doctor_profiles(id) ON DELETE CASCADE,
  appointment_date date NOT NULL,
  start_time time NOT NULL,
  end_time time NOT NULL,
  status text NOT NULL DEFAULT 'available' CHECK (status IN ('available','booked','blocked')),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_slots_doctor_date ON public.appointment_slots(doctor_id, appointment_date);
CREATE UNIQUE INDEX IF NOT EXISTS idx_slots_doctor_date_time ON public.appointment_slots(doctor_id, appointment_date, start_time);

-- ---------- appointments ----------
CREATE TABLE IF NOT EXISTS public.appointments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_reference text UNIQUE NOT NULL,
  patient_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  doctor_id uuid NOT NULL REFERENCES public.doctor_profiles(id) ON DELETE CASCADE,
  slot_id uuid NOT NULL REFERENCES public.appointment_slots(id) ON DELETE CASCADE,
  department_id uuid REFERENCES public.departments(id) ON DELETE SET NULL,
  appointment_date date NOT NULL,
  start_time time NOT NULL,
  end_time time NOT NULL,
  consultation_fee numeric(10,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'booked' CHECK (status IN ('booked','cancelled','completed')),
  cancellation_reason text,
  patient_notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_appt_patient ON public.appointments(patient_id);
CREATE INDEX IF NOT EXISTS idx_appt_doctor ON public.appointments(doctor_id);
CREATE INDEX IF NOT EXISTS idx_appt_slot ON public.appointments(slot_id);
CREATE INDEX IF NOT EXISTS idx_appt_date ON public.appointments(appointment_date);
CREATE UNIQUE INDEX IF NOT EXISTS idx_appt_active_slot ON public.appointments(slot_id) WHERE status = 'booked';

-- ---------- helper role functions ----------
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'admin'
  );
$$;

CREATE OR REPLACE FUNCTION public.is_doctor()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = auth.uid() AND role = 'doctor'
  );
$$;

-- ---------- updated_at trigger ----------
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_profiles_updated ON public.profiles;
CREATE TRIGGER trg_profiles_updated BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

DROP TRIGGER IF EXISTS trg_appt_updated ON public.appointments;
CREATE TRIGGER trg_appt_updated BEFORE UPDATE ON public.appointments
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ---------- RLS ----------
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.departments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.doctor_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.appointment_slots ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;

-- profiles policies
DROP POLICY IF EXISTS "profiles_select_own_or_admin" ON public.profiles;
CREATE POLICY "profiles_select_own_or_admin" ON public.profiles
  FOR SELECT TO authenticated
  USING (auth.uid() = id OR public.is_admin());

DROP POLICY IF EXISTS "profiles_insert_self" ON public.profiles;
CREATE POLICY "profiles_insert_self" ON public.profiles
  FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "profiles_update_own" ON public.profiles;
CREATE POLICY "profiles_update_own" ON public.profiles
  FOR UPDATE TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- departments policies
DROP POLICY IF EXISTS "departments_select_public" ON public.departments;
CREATE POLICY "departments_select_public" ON public.departments
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "departments_insert_admin" ON public.departments;
CREATE POLICY "departments_insert_admin" ON public.departments
  FOR INSERT TO authenticated WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "departments_update_admin" ON public.departments;
CREATE POLICY "departments_update_admin" ON public.departments
  FOR UPDATE TO authenticated USING (public.is_admin()) WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "departments_delete_admin" ON public.departments;
CREATE POLICY "departments_delete_admin" ON public.departments
  FOR DELETE TO authenticated USING (public.is_admin());

-- doctor_profiles policies
DROP POLICY IF EXISTS "doctor_profiles_select_public" ON public.doctor_profiles;
CREATE POLICY "doctor_profiles_select_public" ON public.doctor_profiles
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "doctor_profiles_insert_admin" ON public.doctor_profiles;
CREATE POLICY "doctor_profiles_insert_admin" ON public.doctor_profiles
  FOR INSERT TO authenticated WITH CHECK (public.is_admin());

DROP POLICY IF EXISTS "doctor_profiles_update_admin_or_doctor" ON public.doctor_profiles;
CREATE POLICY "doctor_profiles_update_admin_or_doctor" ON public.doctor_profiles
  FOR UPDATE TO authenticated
  USING (public.is_admin() OR user_id = auth.uid())
  WITH CHECK (public.is_admin() OR user_id = auth.uid());

DROP POLICY IF EXISTS "doctor_profiles_delete_admin" ON public.doctor_profiles;
CREATE POLICY "doctor_profiles_delete_admin" ON public.doctor_profiles
  FOR DELETE TO authenticated USING (public.is_admin());

-- appointment_slots policies
DROP POLICY IF EXISTS "slots_select_public" ON public.appointment_slots;
CREATE POLICY "slots_select_public" ON public.appointment_slots
  FOR SELECT TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "slots_insert_doctor_or_admin" ON public.appointment_slots;
CREATE POLICY "slots_insert_doctor_or_admin" ON public.appointment_slots
  FOR INSERT TO authenticated
  WITH CHECK (
    public.is_admin() OR
    EXISTS (SELECT 1 FROM public.doctor_profiles dp WHERE dp.id = appointment_slots.doctor_id AND dp.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "slots_update_doctor_or_admin" ON public.appointment_slots;
CREATE POLICY "slots_update_doctor_or_admin" ON public.appointment_slots
  FOR UPDATE TO authenticated
  USING (
    public.is_admin() OR
    EXISTS (SELECT 1 FROM public.doctor_profiles dp WHERE dp.id = appointment_slots.doctor_id AND dp.user_id = auth.uid())
  )
  WITH CHECK (
    public.is_admin() OR
    EXISTS (SELECT 1 FROM public.doctor_profiles dp WHERE dp.id = appointment_slots.doctor_id AND dp.user_id = auth.uid())
  );

DROP POLICY IF EXISTS "slots_delete_doctor_or_admin" ON public.appointment_slots;
CREATE POLICY "slots_delete_doctor_or_admin" ON public.appointment_slots
  FOR DELETE TO authenticated
  USING (
    public.is_admin() OR
    EXISTS (SELECT 1 FROM public.doctor_profiles dp WHERE dp.id = appointment_slots.doctor_id AND dp.user_id = auth.uid())
  );

-- appointments policies
DROP POLICY IF EXISTS "appt_select_own_or_doctor_or_admin" ON public.appointments;
CREATE POLICY "appt_select_own_or_doctor_or_admin" ON public.appointments
  FOR SELECT TO authenticated
  USING (
    patient_id = auth.uid() OR
    EXISTS (SELECT 1 FROM public.doctor_profiles dp WHERE dp.id = appointments.doctor_id AND dp.user_id = auth.uid()) OR
    public.is_admin()
  );

DROP POLICY IF EXISTS "appt_insert_patient" ON public.appointments;
CREATE POLICY "appt_insert_patient" ON public.appointments
  FOR INSERT TO authenticated
  WITH CHECK (patient_id = auth.uid());

DROP POLICY IF EXISTS "appt_update_patient_cancel" ON public.appointments;
CREATE POLICY "appt_update_patient_cancel" ON public.appointments
  FOR UPDATE TO authenticated
  USING (patient_id = auth.uid() OR public.is_admin() OR
    EXISTS (SELECT 1 FROM public.doctor_profiles dp WHERE dp.id = appointments.doctor_id AND dp.user_id = auth.uid()))
  WITH CHECK (patient_id = auth.uid() OR public.is_admin() OR
    EXISTS (SELECT 1 FROM public.doctor_profiles dp WHERE dp.id = appointments.doctor_id AND dp.user_id = auth.uid()));

DROP POLICY IF EXISTS "appt_delete_admin" ON public.appointments;
CREATE POLICY "appt_delete_admin" ON public.appointments
  FOR DELETE TO authenticated USING (public.is_admin());

-- ============================================================
-- SEED DATA
-- ============================================================

INSERT INTO public.departments (name, description, icon) VALUES
  ('Cardiology','Heart and vascular care','HeartPulse'),
  ('Dermatology','Skin, hair, and nail care','Shield'),
  ('Orthopedics','Bones, joints, and muscles','Bone'),
  ('Pediatrics','Child health and wellness','Baby'),
  ('Neurology','Brain and nervous system','Brain'),
  ('General Medicine','Primary healthcare','Stethoscope')
ON CONFLICT (name) DO NOTHING;

-- Create auth users + profiles + doctor profiles
-- Demo passwords: adminpass123, doctorpass123, patientpass123
DO $$
DECLARE
  admin_id uuid;
  d1 uuid; d2 uuid; d3 uuid; d4 uuid; d5 uuid; d6 uuid;
  pat_id uuid;
  dept_card uuid; dept_derma uuid; dept_ortho uuid; dept_ped uuid; dept_neuro uuid; dept_gm uuid;
BEGIN
  SELECT id INTO dept_card FROM public.departments WHERE name='Cardiology';
  SELECT id INTO dept_derma FROM public.departments WHERE name='Dermatology';
  SELECT id INTO dept_ortho FROM public.departments WHERE name='Orthopedics';
  SELECT id INTO dept_ped FROM public.departments WHERE name='Pediatrics';
  SELECT id INTO dept_neuro FROM public.departments WHERE name='Neurology';
  SELECT id INTO dept_gm FROM public.departments WHERE name='General Medicine';

  SELECT id INTO admin_id FROM auth.users WHERE email='admin@mgmhospital.com';
  IF admin_id IS NULL THEN
    INSERT INTO auth.users (id, aud, role, email, encrypted_password, email_confirmed_at, created_at, updated_at)
    VALUES (gen_random_uuid(), 'authenticated', 'authenticated', 'admin@mgmhospital.com', crypt('adminpass123', gen_salt('bf')), now(), now(), now())
    RETURNING id INTO admin_id;
  END IF;
  INSERT INTO public.profiles (id, full_name, phone, role) VALUES (admin_id, 'System Administrator', '+919000000000', 'admin')
    ON CONFLICT (id) DO NOTHING;

  SELECT id INTO d1 FROM auth.users WHERE email='dr.sarah@mgmhospital.com';
  IF d1 IS NULL THEN
    INSERT INTO auth.users (id, aud, role, email, encrypted_password, email_confirmed_at, created_at, updated_at)
    VALUES (gen_random_uuid(), 'authenticated', 'authenticated', 'dr.sarah@mgmhospital.com', crypt('doctorpass123', gen_salt('bf')), now(), now(), now())
    RETURNING id INTO d1;
  END IF;
  INSERT INTO public.profiles (id, full_name, phone, role) VALUES (d1, 'Dr. Sarah Chen', '+919111111111', 'doctor') ON CONFLICT (id) DO NOTHING;

  SELECT id INTO d2 FROM auth.users WHERE email='dr.michael@mgmhospital.com';
  IF d2 IS NULL THEN
    INSERT INTO auth.users (id, aud, role, email, encrypted_password, email_confirmed_at, created_at, updated_at)
    VALUES (gen_random_uuid(), 'authenticated', 'authenticated', 'dr.michael@mgmhospital.com', crypt('doctorpass123', gen_salt('bf')), now(), now(), now())
    RETURNING id INTO d2;
  END IF;
  INSERT INTO public.profiles (id, full_name, phone, role) VALUES (d2, 'Dr. Michael Rodriguez', '+919222222222', 'doctor') ON CONFLICT (id) DO NOTHING;

  SELECT id INTO d3 FROM auth.users WHERE email='dr.amit@mgmhospital.com';
  IF d3 IS NULL THEN
    INSERT INTO auth.users (id, aud, role, email, encrypted_password, email_confirmed_at, created_at, updated_at)
    VALUES (gen_random_uuid(), 'authenticated', 'authenticated', 'dr.amit@mgmhospital.com', crypt('doctorpass123', gen_salt('bf')), now(), now(), now())
    RETURNING id INTO d3;
  END IF;
  INSERT INTO public.profiles (id, full_name, phone, role) VALUES (d3, 'Dr. Amit Patel', '+919333333333', 'doctor') ON CONFLICT (id) DO NOTHING;

  SELECT id INTO d4 FROM auth.users WHERE email='dr.emma@mgmhospital.com';
  IF d4 IS NULL THEN
    INSERT INTO auth.users (id, aud, role, email, encrypted_password, email_confirmed_at, created_at, updated_at)
    VALUES (gen_random_uuid(), 'authenticated', 'authenticated', 'dr.emma@mgmhospital.com', crypt('doctorpass123', gen_salt('bf')), now(), now(), now())
    RETURNING id INTO d4;
  END IF;
  INSERT INTO public.profiles (id, full_name, phone, role) VALUES (d4, 'Dr. Emma Thompson', '+919444444444', 'doctor') ON CONFLICT (id) DO NOTHING;

  SELECT id INTO d5 FROM auth.users WHERE email='dr.robert@mgmhospital.com';
  IF d5 IS NULL THEN
    INSERT INTO auth.users (id, aud, role, email, encrypted_password, email_confirmed_at, created_at, updated_at)
    VALUES (gen_random_uuid(), 'authenticated', 'authenticated', 'dr.robert@mgmhospital.com', crypt('doctorpass123', gen_salt('bf')), now(), now(), now())
    RETURNING id INTO d5;
  END IF;
  INSERT INTO public.profiles (id, full_name, phone, role) VALUES (d5, 'Dr. Robert Kim', '+919555555555', 'doctor') ON CONFLICT (id) DO NOTHING;

  SELECT id INTO d6 FROM auth.users WHERE email='dr.lisa@mgmhospital.com';
  IF d6 IS NULL THEN
    INSERT INTO auth.users (id, aud, role, email, encrypted_password, email_confirmed_at, created_at, updated_at)
    VALUES (gen_random_uuid(), 'authenticated', 'authenticated', 'dr.lisa@mgmhospital.com', crypt('doctorpass123', gen_salt('bf')), now(), now(), now())
    RETURNING id INTO d6;
  END IF;
  INSERT INTO public.profiles (id, full_name, phone, role) VALUES (d6, 'Dr. Lisa Wang', '+919666666666', 'doctor') ON CONFLICT (id) DO NOTHING;

  SELECT id INTO pat_id FROM auth.users WHERE email='patient@demo.com';
  IF pat_id IS NULL THEN
    INSERT INTO auth.users (id, aud, role, email, encrypted_password, email_confirmed_at, created_at, updated_at)
    VALUES (gen_random_uuid(), 'authenticated', 'authenticated', 'patient@demo.com', crypt('patientpass123', gen_salt('bf')), now(), now(), now())
    RETURNING id INTO pat_id;
  END IF;
  INSERT INTO public.profiles (id, full_name, phone, role) VALUES (pat_id, 'Demo Patient', '+919777777777', 'patient') ON CONFLICT (id) DO NOTHING;

  INSERT INTO public.doctor_profiles (user_id, department_id, full_name, qualification, specialization, experience_years, consultation_fee, biography, photo_url)
  VALUES
    (d1, dept_card, 'Dr. Sarah Chen', 'MD, DM Cardiology', 'Interventional Cardiology', 12, 800, 'Senior cardiologist specializing in interventional procedures and preventive heart care at MGM Hospital.', 'https://images.pexels.com/photos/5214958/pexels-photo-5214958.jpeg?auto=compress&cs=tinysrgb&w=400'),
    (d2, dept_derma, 'Dr. Michael Rodriguez', 'MD Dermatology', 'Cosmetic & Clinical Dermatology', 9, 600, 'Dermatologist focused on skin health, acne treatment, and cosmetic procedures.', 'https://images.pexels.com/photos/6234600/pexels-photo-6234600.jpeg?auto=compress&cs=tinysrgb&w=400'),
    (d3, dept_ortho, 'Dr. Amit Patel', 'MS Orthopedics', 'Joint Replacement & Sports Injury', 15, 700, 'Orthopedic surgeon with expertise in joint replacement and sports medicine.', 'https://images.pexels.com/photos/5407206/pexels-photo-5407206.jpeg?auto=compress&cs=tinysrgb&w=400'),
    (d4, dept_ped, 'Dr. Emma Thompson', 'MD Pediatrics', 'Child Health & Neonatology', 11, 500, 'Pediatrician dedicated to child wellness, vaccinations, and neonatal care.', 'https://images.pexels.com/photos/5215024/pexels-photo-5215024.jpeg?auto=compress&cs=tinysrgb&w=400'),
    (d5, dept_neuro, 'Dr. Robert Kim', 'MD, DM Neurology', 'Neurology & Stroke Care', 14, 900, 'Neurologist specializing in stroke management and neurological disorders.', 'https://images.pexels.com/photos/6537447/pexels-photo-6537447.jpeg?auto=compress&cs=tinysrgb&w=400'),
    (d6, dept_gm, 'Dr. Lisa Wang', 'MD Internal Medicine', 'General Medicine & Preventive Care', 8, 400, 'General physician focused on preventive care and chronic disease management.', 'https://images.pexels.com/photos/5452201/pexels-photo-5452201.jpeg?auto=compress&cs=tinysrgb&w=400')
  ON CONFLICT DO NOTHING;
END $$;

-- Generate appointment slots for the next 7 days for each active doctor
DO $$
DECLARE
  dp RECORD;
  d int;
  slot_date date;
  start_t time;
  end_t time;
BEGIN
  FOR dp IN SELECT id FROM public.doctor_profiles WHERE active = true LOOP
    FOR d IN 0..6 LOOP
      slot_date := current_date + d;
      start_t := '09:00'::time;
      WHILE start_t < '12:00'::time LOOP
        end_t := start_t + interval '30 minutes';
        INSERT INTO public.appointment_slots (doctor_id, appointment_date, start_time, end_time, status)
        VALUES (dp.id, slot_date, start_t, end_t, 'available')
        ON CONFLICT (doctor_id, appointment_date, start_time) DO NOTHING;
        start_t := end_t;
      END LOOP;
      start_t := '14:00'::time;
      WHILE start_t < '17:00'::time LOOP
        end_t := start_t + interval '30 minutes';
        INSERT INTO public.appointment_slots (doctor_id, appointment_date, start_time, end_time, status)
        VALUES (dp.id, slot_date, start_t, end_t, 'available')
        ON CONFLICT (doctor_id, appointment_date, start_time) DO NOTHING;
        start_t := end_t;
      END LOOP;
    END LOOP;
  END LOOP;
END $$;
